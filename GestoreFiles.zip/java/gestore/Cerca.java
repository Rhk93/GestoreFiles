package gestore;

import android.app.Dialog;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * Ricerca di file e cartelle per nome, nella cartella corrente (e sottocartelle) o ovunque.
 */
public class Cerca {

    private final MainActivity a;
    private final Tema t;
    private final Finestre f;
    private final Handler h = new Handler(Looper.getMainLooper());
    private volatile int giro = 0;          // ogni nuova ricerca annulla la precedente
    private boolean ovunque = false;
    private static final int MAX = 500;

    public Cerca(MainActivity a, Tema t, Finestre f) {
        this.a = a;
        this.t = t;
        this.f = f;
    }

    private int dp(float v) { return f.dp(v); }

    public void mostra(File cartella, File memoria) {
        LinearLayout c = f.colonna();
        final Dialog[] dl = new Dialog[1];

        LinearLayout riga = new LinearLayout(a);
        riga.setGravity(Gravity.CENTER_VERTICAL);
        riga.setBackground(f.fondo(Tema.conAlfa(t.testo, 14), 14));
        riga.setPadding(dp(12), 0, dp(4), 0);
        riga.addView(new Disegni.IconaView(a, "cerca", t.testo2), new LinearLayout.LayoutParams(dp(22), dp(22)));
        final EditText et = new EditText(a);
        et.setHint("Cerca file e cartelle");
        et.setHintTextColor(t.testo2);
        et.setTextColor(t.testo);
        et.setTypeface(t.font());
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, t.grandezzaTesto + 2);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setBackground(null);
        et.setPadding(dp(10), dp(12), dp(10), dp(12));
        riga.addView(et, new LinearLayout.LayoutParams(0, -2, 1));
        android.widget.FrameLayout x = new android.widget.FrameLayout(a);
        x.addView(new Disegni.IconaView(a, "chiudi", t.testo2),
                new android.widget.FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        x.setBackground(f.tocco(0, 20));
        x.setOnClickListener(v -> dl[0].dismiss());
        riga.addView(x, new LinearLayout.LayoutParams(dp(40), dp(40)));
        c.addView(riga);

        // dove cercare
        LinearLayout dove = new LinearLayout(a);
        dove.setPadding(0, dp(10), 0, dp(4));
        final TextView qui = new TextView(a), tutto = new TextView(a);
        final TextView stato = f.testo("Scrivi almeno 2 lettere", t.grandezzaTesto - 2, t.testo2, false);
        final LinearLayout lista = f.colonna();
        final Runnable[] avvia = new Runnable[1];
        Runnable aggiornaDove = () -> {
            stilePillola(qui, !ovunque);
            stilePillola(tutto, ovunque);
        };
        qui.setText("In \"" + a.nomeCartellaPubblico(cartella) + "\"");
        tutto.setText("In tutta la memoria");
        qui.setOnClickListener(v -> { ovunque = false; aggiornaDove.run(); avvia[0].run(); });
        tutto.setOnClickListener(v -> { ovunque = true; aggiornaDove.run(); avvia[0].run(); });
        aggiornaDove.run();
        dove.addView(qui);
        LinearLayout.LayoutParams lt = new LinearLayout.LayoutParams(-2, -2);
        lt.leftMargin = dp(8);
        dove.addView(tutto, lt);
        c.addView(dove);
        stato.setPadding(dp(4), dp(4), 0, dp(6));
        c.addView(stato);

        ScrollView sv = new ScrollView(a);
        sv.addView(lista);
        c.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        avvia[0] = () -> {
            final String q = et.getText().toString().trim().toLowerCase();
            final int mio = ++giro;
            lista.removeAllViews();
            if (q.length() < 2) { stato.setText("Scrivi almeno 2 lettere"); return; }
            stato.setText("Ricerca in corso…");
            final File radice = ovunque ? memoria : cartella;
            new Thread(() -> {
                final List<File> trovati = new ArrayList<>();
                cerca(radice, q, trovati, mio);
                if (mio != giro) return;
                a.runOnUiThread(() -> {
                    if (mio != giro) return;
                    mostraRisultati(lista, trovati, radice, dl);
                    stato.setText(trovati.isEmpty() ? "Nessun risultato"
                            : trovati.size() >= MAX ? "Primi " + MAX + " risultati"
                            : trovati.size() + (trovati.size() == 1 ? " risultato" : " risultati"));
                });
            }).start();
        };

        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a1, int b, int c1) { }
            @Override public void onTextChanged(CharSequence s, int a1, int b, int c1) { }
            @Override public void afterTextChanged(Editable s) {
                h.removeCallbacksAndMessages(null);
                h.postDelayed(avvia[0], 350);
            }
        });

        dl[0] = f.nuova(c, 640);
        Window w = dl[0].getWindow();
        if (w != null) {
            int sw = a.getResources().getDisplayMetrics().widthPixels;
            int sh = a.getResources().getDisplayMetrics().heightPixels;
            w.setLayout(Math.min((int) (sw * 0.94f), dp(640)), (int) (sh * 0.8f));
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        dl[0].setOnDismissListener(d -> giro++);
        dl[0].show();
        et.requestFocus();
    }

    private void stilePillola(TextView v, boolean on) {
        v.setTextColor(on ? 0xFFFFFFFF : t.testo);
        v.setTypeface(on ? t.fontGrassetto() : t.font());
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, t.grandezzaTesto - 1);
        v.setPadding(dp(14), dp(7), dp(14), dp(7));
        v.setBackground(f.tocco(on ? t.accento : Tema.conAlfa(t.testo, 14), 16));
    }

    /** Cerca nei nomi, in tutte le sottocartelle (senza entrare in Android/data). */
    private void cerca(File dir, String q, List<File> out, int mio) {
        if (mio != giro || out.size() >= MAX) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        List<File> sotto = new ArrayList<>();
        for (File x : fs) {
            if (!t.nascosti && x.getName().startsWith(".")) continue;
            if (x.getName().toLowerCase().contains(q)) {
                out.add(x);
                if (out.size() >= MAX) return;
            }
            if (x.isDirectory() && !x.getName().equals("Android")) sotto.add(x);
        }
        for (File s : sotto) cerca(s, q, out, mio);
    }

    private void mostraRisultati(LinearLayout lista, List<File> trovati, File radice, Dialog[] dl) {
        String base = radice.getAbsolutePath();
        for (final File r : trovati) {
            LinearLayout riga = new LinearLayout(a);
            riga.setGravity(Gravity.CENTER_VERTICAL);
            riga.setPadding(dp(10), dp(9), dp(10), dp(9));
            riga.setBackground(f.tocco(0, 10));
            boolean dir = r.isDirectory();
            riga.addView(new Disegni.IconaView(a, dir ? "cartella" : "documento", dir ? t.cartella : t.testo2),
                    new LinearLayout.LayoutParams(dp(22), dp(22)));
            LinearLayout col = f.colonna();
            col.setPadding(dp(12), 0, 0, 0);
            TextView n = f.testo(r.getName(), t.grandezzaTesto + 1, t.testo, false);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            col.addView(n);
            String p = r.getParent() == null ? "" : r.getParent();
            if (p.startsWith(base)) p = "…" + p.substring(base.length());
            TextView pt = f.testo(p.isEmpty() ? "…" : p, t.grandezzaTesto - 2, t.testo2, false);
            pt.setSingleLine(true);
            pt.setEllipsize(android.text.TextUtils.TruncateAt.START);
            col.addView(pt);
            riga.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            // tocco: apre; tenendo premuto: va alla cartella che lo contiene
            riga.setOnClickListener(v -> {
                dl[0].dismiss();
                if (r.isDirectory()) a.apri(r, true, false);
                else a.apriQualsiasi(r);
            });
            riga.setOnLongClickListener(v -> {
                dl[0].dismiss();
                File pd = r.getParentFile();
                if (pd != null) a.apri(pd, true, false);
                return true;
            });
            lista.addView(riga);
        }
    }
}
