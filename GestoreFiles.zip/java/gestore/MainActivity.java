package gestore;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Gestore Files - Copyright © Ignazio Paolicelli
 * Finestra principale: barra di navigazione (spostabile), intestazione con percorso e area delle cartelle.
 */
public class MainActivity extends Activity implements AreaFile.Ascoltatore {

    private Tema tema;
    private Finestre fin;
    private FrameLayout radice;
    private LinearLayout barra, intestazione;
    private AreaFile area;
    private LinearLayout pannelloPermesso;

    private File corrente;
    private final ArrayDeque<File> storia = new ArrayDeque<>();
    private final Map<String, Float> scrollSalvati = new HashMap<>();

    // appunti (copia / taglia)
    private final List<File> appunti = new ArrayList<>();
    private boolean taglia;
    private boolean modoMulti;   // selezione multipla attiva (da "Seleziona" o "Seleziona tutto")

    private SharedPreferences prefPos, prefVarie;
    private final ExecutorService lavoro = Executors.newSingleThreadExecutor();

    private static class Radice {
        String nome, icona;
        File file;
        Radice(String n, String i, File f) { nome = n; icona = i; file = f; }
    }
    private final List<Radice> radici = new ArrayList<>();

    // ------------------------------------------------------------ AVVIO

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        tema = new Tema(this);
        fin = new Finestre(this, tema);
        prefPos = getSharedPreferences("posizioni", MODE_PRIVATE);
        prefVarie = getSharedPreferences("varie", MODE_PRIVATE);

        radice = new FrameLayout(this);
        area = new AreaFile(this, tema);
        area.setAscoltatore(this);
        radice.addView(area, new FrameLayout.LayoutParams(-1, -1));

        intestazione = new LinearLayout(this);
        radice.addView(intestazione);
        barra = new LinearLayout(this);
        radice.addView(barra);
        setContentView(radice);

        trovaRadici();
        String ultimo = prefVarie.getString("ultima", null);
        File start = ultimo != null ? new File(ultimo) : null;
        corrente = (start != null && start.isDirectory()) ? start : radici.get(0).file;
        File daHome = cartellaDaIntent(getIntent());
        if (daHome != null) corrente = daHome;

        applicaTema();
        radice.addOnLayoutChangeListener((v, l, t, r, bb, ol, ot, or, ob) -> {
            if (r - l != or - ol || bb - t != ob - ot) radice.post(this::applicaLayout);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (haAccesso()) {
            nascondiPermesso();
            apri(corrente, false, true);
        } else {
            mostraPermesso();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        salvaPosizioni();
        if (corrente != null) prefVarie.edit().putString("ultima", corrente.getAbsolutePath()).apply();
    }

    private void trovaRadici() {
        radici.clear();
        File in = Environment.getExternalStorageDirectory();
        radici.add(new Radice("Memoria interna", "casa", in));
        aggiungiSeEsiste("Download", "download", new File(in, Environment.DIRECTORY_DOWNLOADS));
        aggiungiSeEsiste("Documenti", "documento", new File(in, Environment.DIRECTORY_DOCUMENTS));
        aggiungiSeEsiste("Immagini", "immagine", new File(in, Environment.DIRECTORY_PICTURES));
        aggiungiSeEsiste("Foto", "foto", new File(in, Environment.DIRECTORY_DCIM));
        aggiungiSeEsiste("Musica", "musica", new File(in, Environment.DIRECTORY_MUSIC));
        aggiungiSeEsiste("Video", "video", new File(in, Environment.DIRECTORY_MOVIES));
        File[] est = getExternalFilesDirs(null);
        int n = 0;
        if (est != null) {
            for (int i = 1; i < est.length; i++) {
                if (est[i] == null) continue;
                String p = est[i].getAbsolutePath();
                int k = p.indexOf("/Android/");
                if (k > 0) {
                    n++;
                    radici.add(new Radice(n == 1 ? "Scheda SD" : "Scheda SD " + n, "sd", new File(p.substring(0, k))));
                }
            }
        }
    }

    private void aggiungiSeEsiste(String nome, String icona, File f) {
        radici.add(new Radice(nome, icona, f));
    }

    // ------------------------------------------------------------ PERMESSI

    private boolean haAccesso() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void chiediAccesso() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    toast("Apri Impostazioni → App → Gestore Files → Permessi e consenti l'accesso ai file");
                }
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        if (haAccesso()) {
            nascondiPermesso();
            apri(corrente, false, true);
        }
    }

    private void mostraPermesso() {
        nascondiPermesso();
        area.setElementi(new ArrayList<>(), null, false);
        area.setMessaggio(" ");
        pannelloPermesso = fin.colonna();
        pannelloPermesso.setGravity(Gravity.CENTER_HORIZONTAL);
        pannelloPermesso.setBackground(fin.fondo(tema.barra, 24));
        pannelloPermesso.setPadding(dp(28), dp(26), dp(28), dp(24));
        pannelloPermesso.setElevation(dp(8));
        pannelloPermesso.addView(new Disegni.LogoView(this, tema.cartella), new LinearLayout.LayoutParams(dp(84), dp(84)));
        TextView t1 = fin.testo("Benvenuto in Gestore Files", tema.grandezzaTesto + 6, tema.testo, true);
        t1.setGravity(Gravity.CENTER);
        t1.setPadding(0, dp(12), 0, dp(8));
        pannelloPermesso.addView(t1);
        TextView t2 = fin.testo("Per mostrarti le tue cartelle l'app ha bisogno del permesso di accedere a tutti i file. "
                + "Nella pagina che si apre attiva \"Consenti accesso per gestire tutti i file\" e poi torna indietro.",
                tema.grandezzaTesto + 1, tema.testo2, false);
        t2.setGravity(Gravity.CENTER);
        pannelloPermesso.addView(t2);
        TextView b = fin.pulsante("Concedi accesso", true, v -> chiediAccesso());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(18);
        pannelloPermesso.addView(b, lp);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(Math.min(dp(440), (int) (getResources().getDisplayMetrics().widthPixels * 0.86f)), -2, Gravity.CENTER);
        radice.addView(pannelloPermesso, fl);
    }

    private void nascondiPermesso() {
        if (pannelloPermesso != null) {
            radice.removeView(pannelloPermesso);
            pannelloPermesso = null;
            area.setMessaggio("");
        }
    }

    // ------------------------------------------------------------ TEMA E DISPOSIZIONE

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** Applica colori, carattere, grandezze e posizione della barra. */
    public void applicaTema() {
        radice.setBackgroundColor(tema.sfondo);
        Window w = getWindow();
        w.setStatusBarColor(tema.sfondo);
        w.setNavigationBarColor(tema.sfondo);
        int fl = 0;
        if (!tema.scuro()) fl = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(fl);
        area.aggiornaMisure();
        costruisciBarra();
        costruisciIntestazione();
        applicaLayout();
        if (pannelloPermesso != null) mostraPermesso();
    }

    private boolean barraVerticale() {
        return tema.posizioneBarra == Tema.SINISTRA || tema.posizioneBarra == Tema.DESTRA;
    }

    private int larghezzaBarra() {
        float wdp = getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density;
        int base = wdp >= 900 ? 230 : (wdp >= 600 ? 200 : 168);
        return dp(base + (tema.grandezzaTesto - 14) * 5);
    }

    private int altezzaBarra() {
        return dp(60 + (tema.grandezzaTesto - 14) * 2);
    }

    /** Posiziona barra, intestazione e area in base alla posizione scelta. */
    public void applicaLayout() {
        int m = dp(10);
        int bw = larghezzaBarra(), bh = altezzaBarra();
        int hh = dp(54 + (tema.grandezzaTesto - 14) * 2);
        int pos = tema.posizioneBarra;

        FrameLayout.LayoutParams lb;
        if (barraVerticale()) {
            lb = new FrameLayout.LayoutParams(bw, -1, pos == Tema.SINISTRA ? Gravity.START : Gravity.END);
        } else {
            lb = new FrameLayout.LayoutParams(-1, bh, pos == Tema.SOPRA ? Gravity.TOP : Gravity.BOTTOM);
        }
        lb.setMargins(m, m, m, m);
        barra.setLayoutParams(lb);

        int sx = m + (pos == Tema.SINISTRA ? bw + m : 0);
        int dx = m + (pos == Tema.DESTRA ? bw + m : 0);
        int su = m + (pos == Tema.SOPRA ? bh + m : 0);
        int giu = m + (pos == Tema.SOTTO ? bh + m : 0);

        FrameLayout.LayoutParams li = new FrameLayout.LayoutParams(-1, hh, Gravity.TOP);
        li.setMargins(sx, su, dx, 0);
        intestazione.setLayoutParams(li);

        area.setMargini(sx, su + hh + dp(6), dx, giu);
        radice.requestLayout();
    }

    private View pulsanteIcona(String tipo, View.OnClickListener cl, View.OnLongClickListener lcl) {
        FrameLayout f = new FrameLayout(this);
        Disegni.IconaView iv = new Disegni.IconaView(this, tipo, tema.testo);
        int s = dp(22 + (tema.grandezzaTesto - 14));
        f.addView(iv, new FrameLayout.LayoutParams(s, s, Gravity.CENTER));
        f.setBackground(fin.tocco(0, 12));
        f.setOnClickListener(cl);
        if (lcl != null) f.setOnLongClickListener(lcl);
        int lato = dp(44 + (tema.grandezzaTesto - 14));
        f.setLayoutParams(new LinearLayout.LayoutParams(lato, lato));
        return f;
    }

    // ------------------------------------------------------------ BARRA DI NAVIGAZIONE

    private void costruisciBarra() {
        barra.removeAllViews();
        boolean vert = barraVerticale();
        barra.setOrientation(vert ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        barra.setGravity(vert ? Gravity.NO_GRAVITY : Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable g = fin.fondo(tema.barraTrasparente(), 20);
        g.setStroke(dp(1), Tema.conAlfa(tema.testo, 22));
        barra.setBackground(g);
        barra.setPadding(dp(8), dp(8), dp(8), dp(8));
        barra.setOnLongClickListener(v -> { menuPosizioneBarra(); return true; });

        String attivo = percorsoAttivo();

        if (vert) {
            LinearLayout testa = new LinearLayout(this);
            testa.setGravity(Gravity.CENTER_VERTICAL);
            testa.setPadding(dp(8), dp(6), dp(4), dp(12));
            testa.addView(new Disegni.LogoView(this, tema.cartella), new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView nome = fin.testo("  Gestore Files", tema.grandezzaTesto + 2, tema.testo, true);
            nome.setSingleLine(true);
            nome.setEllipsize(TextUtils.TruncateAt.END);
            testa.addView(nome, new LinearLayout.LayoutParams(0, -2, 1));
            testa.setOnLongClickListener(v -> { menuPosizioneBarra(); return true; });
            barra.addView(testa);

            ScrollView sv = new ScrollView(this);
            sv.setVerticalScrollBarEnabled(false);
            LinearLayout lista = fin.colonna();
            sv.addView(lista);
            barra.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

            lista.addView(titoletto("Posizioni"));
            for (Radice r : radici) lista.addView(voce(r.icona, r.nome, r.file, attivo, false));
            List<File> pref = preferiti();
            if (!pref.isEmpty()) {
                lista.addView(titoletto("Preferiti"));
                for (File f : pref) lista.addView(voce("stella", f.getName(), f, attivo, true));
            }
            View linea = new View(this);
            linea.setBackgroundColor(Tema.conAlfa(tema.testo, 25));
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, dp(1));
            ll.setMargins(dp(8), dp(6), dp(8), dp(6));
            barra.addView(linea, ll);
            barra.addView(voceAzione("impostazioni", "Impostazioni", v -> new Impostazioni(this, tema).mostra()));
        } else {
            barra.addView(new Disegni.LogoView(this, tema.cartella), new LinearLayout.LayoutParams(dp(34), dp(34)));
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout lista = new LinearLayout(this);
            lista.setGravity(Gravity.CENTER_VERTICAL);
            hs.addView(lista);
            barra.addView(hs, new LinearLayout.LayoutParams(0, -1, 1));
            for (Radice r : radici) lista.addView(voce(r.icona, r.nome, r.file, attivo, false));
            for (File f : preferiti()) lista.addView(voce("stella", f.getName(), f, attivo, true));
            barra.addView(pulsanteIcona("impostazioni", v -> new Impostazioni(this, tema).mostra(), null));
        }
    }

    private TextView titoletto(String s) {
        TextView t = fin.testo(s.toUpperCase(), tema.grandezzaTesto - 3, tema.testo2, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(12), dp(10), dp(8), dp(6));
        return t;
    }

    private View voce(String icona, String nome, File f, String attivo, boolean preferito) {
        boolean on = f.getAbsolutePath().equals(attivo);
        boolean vert = barraVerticale();
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(vert ? 9 : 6), dp(12), dp(vert ? 9 : 6));
        r.setBackground(fin.tocco(on ? Tema.conAlfa(tema.accento, 40) : 0, 12));
        int s = dp(20 + (tema.grandezzaTesto - 14));
        r.addView(new Disegni.IconaView(this, icona, on ? tema.accento : tema.testo2), new LinearLayout.LayoutParams(s, s));
        TextView t = fin.testo("  " + nome, tema.grandezzaTesto, on ? tema.accento : tema.testo, on);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        r.addView(t, vert ? new LinearLayout.LayoutParams(0, -2, 1) : new LinearLayout.LayoutParams(-2, -2));
        r.setOnClickListener(v -> {
            if (!f.isDirectory()) {
                toast("Cartella non trovata");
                return;
            }
            apri(f, true, false);
        });
        r.setOnLongClickListener(v -> {
            if (preferito) {
                fin.menu(nome, new String[]{"Apri", "Rimuovi dai preferiti", "Posizione della barra…"},
                        new String[]{"cartella", "chiudi", "riordina"}, i -> {
                            if (i == 0) apri(f, true, false);
                            else if (i == 1) { togliPreferito(f); costruisciBarra(); }
                            else menuPosizioneBarra();
                        });
            } else menuPosizioneBarra();
            return true;
        });
        LinearLayout.LayoutParams lp = vert ? new LinearLayout.LayoutParams(-1, -2) : new LinearLayout.LayoutParams(-2, -2);
        if (vert) lp.bottomMargin = dp(2); else lp.rightMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private View voceAzione(String icona, String nome, View.OnClickListener cl) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(9), dp(12), dp(9));
        r.setBackground(fin.tocco(0, 12));
        int s = dp(20 + (tema.grandezzaTesto - 14));
        r.addView(new Disegni.IconaView(this, icona, tema.testo2), new LinearLayout.LayoutParams(s, s));
        r.addView(fin.testo("  " + nome, tema.grandezzaTesto, tema.testo, false));
        r.setOnClickListener(cl);
        return r;
    }

    /** La voce della barra che contiene la cartella corrente (la più specifica). */
    private String percorsoAttivo() {
        if (corrente == null) return "";
        String c = corrente.getAbsolutePath(), best = "";
        List<File> tutte = new ArrayList<>();
        for (Radice r : radici) tutte.add(r.file);
        tutte.addAll(preferiti());
        for (File f : tutte) {
            String p = f.getAbsolutePath();
            if ((c.equals(p) || c.startsWith(p + "/")) && p.length() > best.length()) best = p;
        }
        return best;
    }

    private void menuPosizioneBarra() {
        String[] v = new String[4];
        for (int i = 0; i < 4; i++) v[i] = (tema.posizioneBarra == i ? "✓  " : "     ") + Tema.NOMI_POSIZIONE[i];
        fin.menu("Dove vuoi la barra?", v, null, i -> {
            tema.posizioneBarra = i;
            tema.salva();
            applicaTema();
        });
    }

    // ------------------------------------------------------------ INTESTAZIONE

    private int selezionati() {
        int n = 0;
        for (AreaFile.Elemento e : area.elementi) if (e.sel) n++;
        return n;
    }

    private void costruisciIntestazione() {
        intestazione.removeAllViews();
        intestazione.setOrientation(LinearLayout.HORIZONTAL);
        intestazione.setGravity(Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable g = fin.fondo(tema.barraTrasparente(), 16);
        g.setStroke(dp(1), Tema.conAlfa(tema.testo, 22));
        intestazione.setBackground(g);
        intestazione.setPadding(dp(4), 0, dp(4), 0);

        int n = selezionati();
        if (modoMulti && n > 0) {
            intestazione.addView(pulsanteIcona("chiudi", v -> deseleziona(), null));
            TextView t = fin.testo(n == 1 ? "1 selezionato" : n + " selezionati", tema.grandezzaTesto + 1, tema.testo, true);
            t.setPadding(dp(6), 0, 0, 0);
            intestazione.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            intestazione.addView(pulsanteTesto("Tutti", v -> selezionaTutto()));
            intestazione.addView(pulsanteTesto("Copia", v -> metti(selezione(), false)));
            intestazione.addView(pulsanteTesto("Taglia", v -> metti(selezione(), true)));
            intestazione.addView(pulsanteTesto("Elimina", v -> chiediElimina(selezione())));
            return;
        }

        intestazione.addView(pulsanteIcona("indietro", v -> indietro(), null));
        intestazione.addView(pulsanteIcona("su", v -> cartellaSu(), null));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout briciole = new LinearLayout(this);
        briciole.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(briciole);
        intestazione.addView(hs, new LinearLayout.LayoutParams(0, -1, 1));
        riempiBriciole(briciole);
        hs.post(() -> hs.fullScroll(View.FOCUS_RIGHT));

        if (!appunti.isEmpty()) {
            View inc = pulsanteIcona("incolla", v -> incolla(corrente), null);
            intestazione.addView(inc);
        }
        intestazione.addView(pulsanteIcona("nuova", v -> nuovaCartella(), null));
        intestazione.addView(pulsanteIcona("riordina", v -> riordina(), v -> { menuOrdina(); return true; }));
        intestazione.addView(pulsanteIcona("menu", v -> menuArea(), null));
    }

    private View pulsanteTesto(String s, View.OnClickListener cl) {
        TextView b = fin.testo(s, tema.grandezzaTesto, s.equals("Elimina") ? 0xFFE5484D : tema.testo, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setBackground(fin.tocco(0, 12));
        b.setOnClickListener(cl);
        return b;
    }

    private void riempiBriciole(LinearLayout l) {
        if (corrente == null) return;
        String c = corrente.getAbsolutePath();
        Radice base = null;
        for (Radice r : radici) {
            String p = r.file.getAbsolutePath();
            boolean principale = r.nome.startsWith("Memoria") || r.nome.startsWith("Scheda");
            if (principale && (c.equals(p) || c.startsWith(p + "/"))) {
                if (base == null || p.length() > base.file.getAbsolutePath().length()) base = r;
            }
        }
        List<File> pezzi = new ArrayList<>();
        File f = corrente;
        File stop = base != null ? base.file : null;
        while (f != null) {
            pezzi.add(0, f);
            if (stop != null && f.getAbsolutePath().equals(stop.getAbsolutePath())) break;
            f = f.getParentFile();
        }
        for (int i = 0; i < pezzi.size(); i++) {
            final File p = pezzi.get(i);
            String nome = (i == 0 && base != null) ? base.nome : (p.getName().isEmpty() ? "/" : p.getName());
            boolean ultimo = i == pezzi.size() - 1;
            if (i > 0) {
                TextView sep = fin.testo("›", tema.grandezzaTesto + 3, tema.testo2, false);
                sep.setPadding(dp(2), 0, dp(2), dp(2));
                l.addView(sep);
            }
            TextView t = fin.testo(nome, tema.grandezzaTesto + 1, ultimo ? tema.testo : tema.testo2, ultimo);
            t.setPadding(dp(8), dp(6), dp(8), dp(6));
            t.setSingleLine(true);
            t.setBackground(fin.tocco(0, 10));
            t.setOnClickListener(v -> { if (!ultimo) apri(p, true, false); });
            l.addView(t);
        }
    }

    // ------------------------------------------------------------ NAVIGAZIONE

    private Comparator<File> comparatore() {
        return (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
            switch (tema.ordine) {
                case 1: return Long.compare(b.lastModified(), a.lastModified());
                case 2: {
                    int c = Long.compare(b.length(), a.length());
                    if (c != 0 && !a.isDirectory()) return c;
                    break;
                }
                case 3: {
                    int c = OperazioniFile.estensione(a.getName()).compareToIgnoreCase(OperazioniFile.estensione(b.getName()));
                    if (c != 0) return c;
                    break;
                }
            }
            return a.getName().compareToIgnoreCase(b.getName());
        };
    }

    private List<File> elenca(File dir) {
        List<File> l = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) {
            if (!tema.nascosti && f.getName().startsWith(".")) continue;
            l.add(f);
        }
        Collections.sort(l, comparatore());
        return l;
    }

    /** Apre una cartella. storiaSi = ricorda la cartella precedente per "Indietro". */
    public void apri(File dir, boolean storiaSi, boolean tienScroll) {
        if (dir == null) return;
        if (!dir.canRead()) {
            toast("Questa cartella non si può aprire");
            return;
        }
        boolean stessa = corrente != null && corrente.getAbsolutePath().equals(dir.getAbsolutePath());
        if (!stessa) {
            salvaPosizioni();
            if (corrente != null) scrollSalvati.put(corrente.getAbsolutePath(), area.getScrollPos());
            if (storiaSi && corrente != null) storia.push(corrente);
        } else if (corrente != null) {
            salvaPosizioni();
        }
        float sc = stessa ? area.getScrollPos() : 0;
        corrente = dir;
        modoMulti = false;
        List<AreaFile.Elemento> el = new ArrayList<>();
        for (File f : elenca(dir)) el.add(new AreaFile.Elemento(f));
        area.setElementi(el, caricaPosizioni(dir), stessa && tienScroll);
        if (!stessa) {
            Float s = scrollSalvati.get(dir.getAbsolutePath());
            if (s != null && !storiaSi) area.setScrollPos(s);
        } else area.setScrollPos(sc);
        salvaPosizioni();
        costruisciIntestazione();
        costruisciBarra();
    }

    public void ricarica() {
        if (haAccesso()) apri(corrente, false, true);
    }

    private void indietro() {
        if (!storia.isEmpty()) {
            File p = storia.pop();
            apri(p, false, false);
        } else cartellaSu();
    }

    private boolean eRadice(File f) {
        for (Radice r : radici)
            if ((r.nome.startsWith("Memoria") || r.nome.startsWith("Scheda"))
                    && r.file.getAbsolutePath().equals(f.getAbsolutePath())) return true;
        return false;
    }

    private void cartellaSu() {
        if (corrente == null || eRadice(corrente)) {
            toast("Sei già nella cartella principale");
            return;
        }
        File p = corrente.getParentFile();
        if (p != null && p.canRead()) apri(p, true, false);
    }

    @Override
    public void onBackPressed() {
        if (selezionati() > 0) { deseleziona(); return; }
        if (!storia.isEmpty()) { apri(storia.pop(), false, false); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------ POSIZIONI

    private void salvaPosizioni() {
        if (corrente == null || !haAccesso()) return;
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, float[]> e : area.posizioni().entrySet()) {
                JSONArray a = new JSONArray();
                a.put((double) e.getValue()[0]);
                a.put((double) e.getValue()[1]);
                o.put(e.getKey(), a);
            }
            if (area.elementi.isEmpty()) return;
            prefPos.edit().putString(corrente.getAbsolutePath(), o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private Map<String, float[]> caricaPosizioni(File dir) {
        Map<String, float[]> m = new HashMap<>();
        String s = prefPos.getString(dir.getAbsolutePath(), null);
        if (s == null) return m;
        try {
            JSONObject o = new JSONObject(s);
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONArray a = o.getJSONArray(k);
                m.put(k, new float[]{(float) a.getDouble(0), (float) a.getDouble(1)});
            }
        } catch (Exception ignored) {
        }
        return m;
    }

    private void rinominaPosizione(String vecchio, String nuovo) {
        Map<String, float[]> m = area.posizioni();
        float[] p = m.remove(vecchio);
        if (p != null) m.put(nuovo, p);
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, float[]> e : m.entrySet()) {
                JSONArray a = new JSONArray();
                a.put((double) e.getValue()[0]);
                a.put((double) e.getValue()[1]);
                o.put(e.getKey(), a);
            }
            prefPos.edit().putString(corrente.getAbsolutePath(), o.toString()).commit();
        } catch (Exception ignored) {
        }
    }

    /** Mette tutto in fila con gli spazi giusti, nell'ordine scelto. */
    private void riordina() {
        List<AreaFile.Elemento> l = new ArrayList<>(area.elementi);
        final Comparator<File> c = comparatore();
        Collections.sort(l, (a, b) -> c.compare(a.file, b.file));
        area.disponiInGriglia(l, true);
        salvaPosizioni();
    }

    private void menuOrdina() {
        String[] n = {"Nome", "Data (più recenti prima)", "Dimensione (più grandi prima)", "Tipo di file"};
        String[] v = new String[4];
        for (int i = 0; i < 4; i++) v[i] = (tema.ordine == i ? "✓  " : "     ") + n[i];
        fin.menu("Riordina per…", v, null, i -> {
            tema.ordine = i;
            tema.salva();
            riordina();
        });
    }

    // ------------------------------------------------------------ TOCCHI SULL'AREA

    /** Un tocco: seleziona soltanto (in selezione multipla aggiunge/toglie). */
    @Override
    public void tocco(AreaFile.Elemento e) {
        if (e == null) {
            if (selezionati() > 0) deseleziona();
            return;
        }
        if (modoMulti) {
            e.sel = !e.sel;
            if (selezionati() == 0) modoMulti = false;
        } else {
            for (AreaFile.Elemento x : area.elementi) x.sel = (x == e);
        }
        area.invalidate();
        costruisciIntestazione();
    }

    /** Due tocchi: apre la cartella o il file. */
    @Override
    public void doppioTocco(AreaFile.Elemento e) {
        if (e == null) return;
        if (modoMulti) {
            tocco(e);
            return;
        }
        if (e.dir) apri(e.file, true, false);
        else apriFile(e.file, false);
    }

    @Override
    public void pressione(AreaFile.Elemento e) {
        fin.ancora = e == null ? area.puntoPressione() : area.rettangoloSchermo(e);
        if (e == null) { menuArea(); return; }
        if (e.sel && selezionati() > 1) { menuSelezione(); return; }
        menuElemento(e);
    }

    @Override
    public void rilasciaSu(List<AreaFile.Elemento> trascinati, AreaFile.Elemento cartella) {
        List<File> fs = new ArrayList<>();
        for (AreaFile.Elemento e : trascinati) fs.add(e.file);
        String cosa = fs.size() == 1 ? "\"" + fs.get(0).getName() + "\"" : fs.size() + " elementi";
        fin.conferma("Mettere " + cosa + " in \"" + cartella.nome + "\"?", null,
                new String[]{"Sposta", "Copia", "Annulla"}, i -> {
                    if (i == 2) {
                        area.ripristina(trascinati);
                        salvaPosizioni();
                    } else {
                        area.ripristina(trascinati);
                        esegui(fs, cartella.file, i == 0);
                    }
                });
    }

    @Override
    public void posizioniCambiate() {
        salvaPosizioni();
    }

    // ------------------------------------------------------------ MENU

    private void menuElemento(AreaFile.Elemento e) {
        List<String> v = new ArrayList<>();
        List<String> ic = new ArrayList<>();
        List<Runnable> az = new ArrayList<>();
        final File f = e.file;
        if (e.dir) {
            v.add("Apri"); ic.add("cartella"); az.add(() -> apri(f, true, false));
        } else {
            v.add("Apri"); ic.add("documento"); az.add(() -> apriFile(f, false));
            v.add("Apri con…"); ic.add("avanti"); az.add(() -> apriFile(f, true));
            v.add("Condividi"); ic.add("download"); az.add(() -> condividi(Collections.singletonList(f)));
        }
        v.add("Seleziona"); ic.add("riordina"); az.add(() -> { modoMulti = true; e.sel = true; area.invalidate(); costruisciIntestazione(); });
        v.add("Copia"); ic.add("documento"); az.add(() -> metti(Collections.singletonList(f), false));
        v.add("Taglia"); ic.add("chiudi"); az.add(() -> metti(Collections.singletonList(f), true));
        if (e.dir && !appunti.isEmpty()) {
            v.add("Incolla qui dentro (" + appunti.size() + ")"); ic.add("incolla"); az.add(() -> incolla(f));
        }
        v.add("Rinomina"); ic.add("documento"); az.add(() -> rinomina(f));
        v.add("Duplica"); ic.add("nuova"); az.add(() -> esegui(Collections.singletonList(f), f.getParentFile(), false));
        if (e.dir) {
            if (ePreferito(f)) {
                v.add("Rimuovi dai preferiti"); ic.add("stella"); az.add(() -> { togliPreferito(f); costruisciBarra(); });
            } else {
                v.add("Aggiungi ai preferiti"); ic.add("stella"); az.add(() -> { aggiungiPreferito(f); costruisciBarra(); });
            }
        }
        if (e.dir) {
            v.add("Aggiungi alla schermata Home"); ic.add("casa"); az.add(() -> collegamentoHome(f));
        }
        v.add("Informazioni"); ic.add("menu"); az.add(() -> informazioni(f));
        v.add("Elimina"); ic.add("chiudi"); az.add(() -> chiediElimina(Collections.singletonList(f)));
        fin.menu(e.nome, v.toArray(new String[0]), ic.toArray(new String[0]), i -> az.get(i).run());
    }

    private void menuArea() {
        List<String> v = new ArrayList<>();
        List<String> ic = new ArrayList<>();
        List<Runnable> az = new ArrayList<>();
        v.add("Nuova cartella"); ic.add("nuova"); az.add(this::nuovaCartella);
        v.add("Nuovo file di testo"); ic.add("documento"); az.add(this::nuovoFile);
        if (!appunti.isEmpty()) {
            v.add("Incolla (" + appunti.size() + ")"); ic.add("incolla"); az.add(() -> incolla(corrente));
        }
        v.add("Riordina"); ic.add("riordina"); az.add(this::riordina);
        v.add("Riordina per…"); ic.add("riordina"); az.add(this::menuOrdina);
        v.add("Seleziona tutto"); ic.add("riordina"); az.add(this::selezionaTutto);
        v.add("Aggiorna"); ic.add("aggiorna"); az.add(this::ricarica);
        v.add("Posizione della barra…"); ic.add("menu"); az.add(this::menuPosizioneBarra);
        v.add("Impostazioni"); ic.add("impostazioni"); az.add(() -> new Impostazioni(this, tema).mostra());
        fin.menu(corrente != null ? nomeCartella(corrente) : "Gestore Files",
                v.toArray(new String[0]), ic.toArray(new String[0]), i -> az.get(i).run());
    }

    private void menuSelezione() {
        final List<File> sel = selezione();
        boolean tuttiFile = true;
        for (File f : sel) if (f.isDirectory()) { tuttiFile = false; break; }
        List<String> v = new ArrayList<>();
        List<String> ic = new ArrayList<>();
        List<Runnable> az = new ArrayList<>();
        v.add("Copia (" + sel.size() + ")"); ic.add("documento"); az.add(() -> metti(sel, false));
        v.add("Taglia (" + sel.size() + ")"); ic.add("chiudi"); az.add(() -> metti(sel, true));
        if (tuttiFile) { v.add("Condividi"); ic.add("download"); az.add(() -> condividi(sel)); }
        v.add("Seleziona tutto"); ic.add("riordina"); az.add(this::selezionaTutto);
        v.add("Deseleziona"); ic.add("chiudi"); az.add(this::deseleziona);
        v.add("Elimina (" + sel.size() + ")"); ic.add("chiudi"); az.add(() -> chiediElimina(sel));
        fin.menu(sel.size() + " selezionati", v.toArray(new String[0]), ic.toArray(new String[0]), i -> az.get(i).run());
    }

    private String nomeCartella(File f) {
        for (Radice r : radici) if (r.file.getAbsolutePath().equals(f.getAbsolutePath())) return r.nome;
        return f.getName();
    }

    // ------------------------------------------------------------ SELEZIONE

    private List<File> selezione() {
        List<File> l = new ArrayList<>();
        for (AreaFile.Elemento e : area.elementi) if (e.sel) l.add(e.file);
        return l;
    }

    private void selezionaTutto() {
        modoMulti = true;
        for (AreaFile.Elemento e : area.elementi) e.sel = true;
        area.invalidate();
        costruisciIntestazione();
    }

    private void deseleziona() {
        modoMulti = false;
        for (AreaFile.Elemento e : area.elementi) e.sel = false;
        area.invalidate();
        costruisciIntestazione();
    }

    // ------------------------------------------------------------ OPERAZIONI

    private void metti(List<File> fs, boolean tagliare) {
        appunti.clear();
        appunti.addAll(fs);
        taglia = tagliare;
        modoMulti = false;
        for (AreaFile.Elemento e : area.elementi) e.sel = false;
        area.invalidate();
        costruisciIntestazione();
        String cosa = fs.size() == 1 ? "\"" + fs.get(0).getName() + "\"" : fs.size() + " elementi";
        toast((tagliare ? "Tagliato " : "Copiato ") + cosa + ": ora apri la cartella e tocca Incolla");
    }

    private void incolla(File dest) {
        if (appunti.isEmpty()) return;
        List<File> fs = new ArrayList<>(appunti);
        boolean sp = taglia;
        if (sp) appunti.clear();
        esegui(fs, dest, sp);
    }

    /** Copia o sposta i file nella cartella di destinazione, in sottofondo. */
    private void esegui(List<File> fs, File dest, boolean spostare) {
        final Finestre.Progresso pr = fin.progresso(spostare ? "Spostamento in corso" : "Copia in corso");
        lavoro.execute(() -> {
            String errore = null;
            int fatti = 0;
            OperazioniFile.Avanzamento av = new OperazioniFile.Avanzamento() {
                @Override public void file(String nome) { pr.file(nome); }
                @Override public boolean annullato() { return pr.annullato; }
            };
            for (File f : fs) {
                if (pr.annullato) break;
                try {
                    if (f.isDirectory() && OperazioniFile.dentro(dest, f)) {
                        errore = "Non si può mettere una cartella dentro sé stessa.";
                        continue;
                    }
                    File parent = f.getParentFile();
                    if (spostare && parent != null && parent.getAbsolutePath().equals(dest.getAbsolutePath())) continue;
                    File a = OperazioniFile.nomeLibero(dest, f.getName());
                    if (spostare) OperazioniFile.sposta(f, a, av);
                    else OperazioniFile.copia(f, a, av);
                    fatti++;
                } catch (Exception ex) {
                    errore = "Errore con \"" + f.getName() + "\": " + ex.getMessage();
                }
            }
            pr.chiudi();
            final String err = errore;
            final int n = fatti;
            runOnUiThread(() -> {
                ricarica();
                costruisciIntestazione();
                if (err != null) fin.avviso("Attenzione", err);
                else if (n > 0) toast(spostare ? "Spostato" : "Copiato");
            });
        });
    }

    private void chiediElimina(List<File> fs) {
        if (fs.isEmpty()) return;
        String cosa = fs.size() == 1 ? "\"" + fs.get(0).getName() + "\"" : fs.size() + " elementi";
        fin.conferma("Eliminare " + cosa + "?", "Verrà cancellato definitivamente e non si potrà recuperare.",
                new String[]{"Elimina", "Annulla"}, i -> {
                    if (i != 0) return;
                    final Finestre.Progresso pr = fin.progresso("Eliminazione in corso");
                    lavoro.execute(() -> {
                        boolean ok = true;
                        for (File f : fs) {
                            if (pr.annullato) break;
                            pr.file(f.getName());
                            if (!OperazioniFile.elimina(f)) ok = false;
                        }
                        pr.chiudi();
                        final boolean tuttoOk = ok;
                        runOnUiThread(() -> {
                            appunti.removeAll(fs);
                            ricarica();
                            if (!tuttoOk) fin.avviso("Attenzione", "Alcuni elementi non sono stati eliminati.");
                        });
                    });
                });
    }

    private boolean nomeValido(String n) {
        if (n == null || n.isEmpty()) { toast("Scrivi un nome"); return false; }
        if (n.contains("/") || n.equals(".") || n.equals("..")) { toast("Il nome non può contenere /"); return false; }
        return true;
    }

    private void nuovaCartella() {
        if (corrente == null) return;
        String prop = OperazioniFile.nomeLibero(corrente, "Nuova cartella").getName();
        fin.chiedi("Nuova cartella", prop, "Crea", false, n -> {
            if (!nomeValido(n)) return;
            File f = new File(corrente, n);
            if (f.exists()) { toast("Esiste già un elemento con questo nome"); return; }
            if (f.mkdirs()) ricarica();
            else toast("Impossibile creare la cartella");
        });
    }

    private void nuovoFile() {
        if (corrente == null) return;
        String prop = OperazioniFile.nomeLibero(corrente, "Nuovo documento.txt").getName();
        fin.chiedi("Nuovo file di testo", prop, "Crea", true, n -> {
            if (!nomeValido(n)) return;
            File f = new File(corrente, n);
            if (f.exists()) { toast("Esiste già un elemento con questo nome"); return; }
            try {
                if (f.createNewFile()) ricarica();
            } catch (Exception ex) {
                toast("Impossibile creare il file");
            }
        });
    }

    private void rinomina(File f) {
        fin.chiedi("Rinomina", f.getName(), "Rinomina", !f.isDirectory(), n -> {
            if (!nomeValido(n) || n.equals(f.getName())) return;
            File nuovo = new File(f.getParentFile(), n);
            if (nuovo.exists()) { toast("Esiste già un elemento con questo nome"); return; }
            String vecchio = f.getName();
            if (f.renameTo(nuovo)) {
                rinominaPosizione(vecchio, n);
                if (ePreferito(f)) { togliPreferito(f); aggiungiPreferito(nuovo); }
                ricarica();
            } else toast("Impossibile rinominare");
        });
    }

    private void informazioni(File f) {
        SimpleDateFormat df = new SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.ITALIAN);
        String tipo = f.isDirectory() ? "Cartella" : ("File " + OperazioniFile.estensione(f.getName()).toUpperCase());
        String base = "Tipo: " + tipo + "\nPercorso: " + f.getParent() + "\nModificato: " + df.format(new Date(f.lastModified()));
        if (!f.isDirectory()) {
            fin.avviso(f.getName(), base + "\nDimensione: " + OperazioniFile.leggibile(f.length()));
            return;
        }
        final Finestre.Progresso pr = fin.progresso("Calcolo dimensione…");
        lavoro.execute(() -> {
            long d = OperazioniFile.dimensione(f);
            int n = OperazioniFile.conta(f);
            pr.chiudi();
            runOnUiThread(() -> fin.avviso(f.getName(), base + "\nDimensione: " + OperazioniFile.leggibile(d)
                    + "\nContiene: " + n + " file"));
        });
    }

    // ------------------------------------------------------------ APRI / CONDIVIDI

    private void apriFile(File f, boolean scegliApp) {
        Uri u = FilesProvider.uriDi(f);
        String mime = FilesProvider.mime(f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(u, mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            if (scegliApp || "*/*".equals(mime)) startActivity(Intent.createChooser(i, "Apri con"));
            else startActivity(i);
        } catch (ActivityNotFoundException ex) {
            try {
                Intent j = new Intent(Intent.ACTION_VIEW);
                j.setDataAndType(u, "*/*");
                j.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(j, "Apri con"));
            } catch (Exception ex2) {
                toast("Nessuna app può aprire questo file");
            }
        }
    }

    private void condividi(List<File> fs) {
        if (fs.isEmpty()) return;
        Intent i;
        if (fs.size() == 1) {
            Uri u = FilesProvider.uriDi(fs.get(0));
            i = new Intent(Intent.ACTION_SEND);
            i.setType(mimeDi(fs.get(0)));
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(ClipData.newRawUri("", u));
        } else {
            ArrayList<Uri> us = new ArrayList<>();
            for (File f : fs) us.add(FilesProvider.uriDi(f));
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.setType("*/*");
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, us);
            ClipData cd = ClipData.newRawUri("", us.get(0));
            for (int k = 1; k < us.size(); k++) cd.addItem(new ClipData.Item(us.get(k)));
            i.setClipData(cd);
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Condividi"));
        } catch (Exception ex) {
            toast("Impossibile condividere");
        }
        deseleziona();
    }

    private String mimeDi(File f) {
        String m = FilesProvider.mime(f);
        return "*/*".equals(m) ? "application/octet-stream" : m;
    }

    // ------------------------------------------------------------ PREFERITI

    private List<File> preferiti() {
        List<File> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefVarie.getString("preferiti", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(new File(a.getString(i)));
        } catch (Exception ignored) {
        }
        return l;
    }

    private void salvaPreferiti(List<File> l) {
        JSONArray a = new JSONArray();
        for (File f : l) a.put(f.getAbsolutePath());
        prefVarie.edit().putString("preferiti", a.toString()).apply();
    }

    private boolean ePreferito(File f) {
        for (File p : preferiti()) if (p.getAbsolutePath().equals(f.getAbsolutePath())) return true;
        return false;
    }

    private void aggiungiPreferito(File f) {
        List<File> l = preferiti();
        if (!ePreferito(f)) l.add(f);
        salvaPreferiti(l);
        toast("Aggiunta ai preferiti nella barra");
    }

    private void togliPreferito(File f) {
        List<File> l = preferiti();
        Iterator<File> it = l.iterator();
        while (it.hasNext()) if (it.next().getAbsolutePath().equals(f.getAbsolutePath())) it.remove();
        salvaPreferiti(l);
    }

    // ------------------------------------------------------------ COLLEGAMENTI SULLA HOME

    private File cartellaDaIntent(Intent i) {
        if (i == null) return null;
        String p = i.getStringExtra("cartella");
        if (p == null) return null;
        File f = new File(p);
        return f.isDirectory() ? f : null;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        File f = cartellaDaIntent(i);
        if (f != null) {
            if (haAccesso()) apri(f, true, false);
            else corrente = f;
        }
    }

    /** Disegna l'icona della cartella con i colori dell'app. */
    private android.graphics.Bitmap iconaCartella(int lato, boolean adattiva) {
        android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(lato, lato, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFF5F4EE);
        if (adattiva) c.drawRect(0, 0, lato, lato, p);
        else c.drawRoundRect(new android.graphics.RectF(0, 0, lato, lato), lato * 0.22f, lato * 0.22f, p);
        Disegni.cartella(c, lato / 2f, lato / 2f, lato * (adattiva ? 0.46f : 0.62f), tema.cartella);
        return b;
    }

    private void collegamentoHome(File f) {
        String nome = nomeCartella(f);
        Intent apri = new Intent(this, MainActivity.class);
        apri.setAction(Intent.ACTION_VIEW);
        apri.putExtra("cartella", f.getAbsolutePath());
        apri.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            android.content.pm.ShortcutManager sm = getSystemService(android.content.pm.ShortcutManager.class);
            if (sm != null && sm.isRequestPinShortcutSupported()) {
                android.content.pm.ShortcutInfo si = new android.content.pm.ShortcutInfo.Builder(this,
                        "cartella_" + Math.abs(f.getAbsolutePath().hashCode()))
                        .setShortLabel(nome)
                        .setLongLabel(nome)
                        .setIcon(android.graphics.drawable.Icon.createWithAdaptiveBitmap(iconaCartella(432, true)))
                        .setIntent(apri)
                        .build();
                sm.requestPinShortcut(si, null);
                toast("Conferma per mettere \"" + nome + "\" sulla schermata Home");
                return;
            }
        } catch (Exception ignored) {
        }
        // metodo vecchio (alcuni launcher Huawei)
        Intent add = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        add.putExtra(Intent.EXTRA_SHORTCUT_INTENT, apri);
        add.putExtra(Intent.EXTRA_SHORTCUT_NAME, nome);
        add.putExtra(Intent.EXTRA_SHORTCUT_ICON, iconaCartella(192, false));
        add.putExtra("duplicate", false);
        sendBroadcast(add);
        toast("Collegamento \"" + nome + "\" aggiunto alla schermata Home");
    }

    // ------------------------------------------------------------ VARIE

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
