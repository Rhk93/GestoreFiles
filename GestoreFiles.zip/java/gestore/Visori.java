package gestore;

import android.app.Dialog;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * Visualizzatore di archivi compressi (contenuto, apri, estrai) e di file di testo.
 */
public class Visori {

    private final MainActivity a;
    private final Tema t;
    private final Finestre f;
    private final ExecutorService lavoro;

    public Visori(MainActivity a, Tema t, Finestre f, ExecutorService lavoro) {
        this.a = a;
        this.t = t;
        this.f = f;
        this.lavoro = lavoro;
    }

    private int dp(float v) { return f.dp(v); }

    public static boolean eTesto(String est) {
        switch (est.toLowerCase()) {
            case "txt": case "md": case "log": case "csv": case "json": case "xml": case "html": case "htm":
            case "css": case "js": case "java": case "kt": case "py": case "c": case "cpp": case "h": case "ini":
            case "cfg": case "conf": case "yml": case "yaml": case "properties": case "srt": case "sh":
            case "gradle": case "sql": case "tex": case "nfo": case "lrc": case "vtt": case "bat":
                return true;
        }
        return false;
    }

    private Dialog grande(LinearLayout c) {
        Dialog dl = f.nuova(c, 720);
        Window w = dl.getWindow();
        if (w != null) {
            int sw = a.getResources().getDisplayMetrics().widthPixels;
            int sh = a.getResources().getDisplayMetrics().heightPixels;
            w.setLayout(Math.min((int) (sw * 0.94f), dp(720)), (int) (sh * 0.86f));
        }
        return dl;
    }

    private LinearLayout testata(String titolo, String sotto, Runnable chiudi) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout col = f.colonna();
        TextView ti = f.testo(titolo, t.grandezzaTesto + 4, t.testo, true);
        ti.setSingleLine(true);
        ti.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(ti);
        if (sotto != null) col.addView(f.testo(sotto, t.grandezzaTesto - 1, t.testo2, false));
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        android.widget.FrameLayout x = new android.widget.FrameLayout(a);
        x.addView(new Disegni.IconaView(a, "chiudi", t.testo2),
                new android.widget.FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        x.setBackground(f.tocco(0, 20));
        x.setOnClickListener(v -> chiudi.run());
        r.addView(x, new LinearLayout.LayoutParams(dp(42), dp(42)));
        return r;
    }

    // ------------------------------------------------------------ TESTO

    /** Mostra un file come testo (anche file sconosciuti). */
    public void testo(File file) {
        final Finestre.Progresso pr = f.progresso("Apertura…");
        lavoro.execute(() -> {
            String s;
            boolean tagliato = false;
            try (InputStream in = new FileInputStream(file)) {
                int max = 1024 * 1024;
                byte[] b = new byte[(int) Math.min(max, Math.max(0, file.length()))];
                int letti = 0, n;
                while (letti < b.length && (n = in.read(b, letti, b.length - letti)) > 0) letti += n;
                tagliato = file.length() > max;
                s = new String(b, 0, letti, Charset.forName("UTF-8"));
                int strani = 0;
                for (int i = 0; i < Math.min(letti, 4000); i++) if (b[i] == 0) strani++;
                if (strani > 20) s = "Questo file non contiene testo leggibile (è un file binario).\n"
                        + "Usa \"Apri con…\" per sceglierne l'app.";
            } catch (Exception e) {
                s = "Impossibile leggere il file: " + e.getMessage();
            }
            pr.chiudi();
            final String testo = s;
            final boolean tg = tagliato;
            a.runOnUiThread(() -> {
                LinearLayout c = f.colonna();
                final Dialog[] dl = new Dialog[1];
                c.addView(testata(file.getName(), OperazioniFile.leggibile(file.length())
                        + (tg ? " · mostrato il primo MB" : ""), () -> dl[0].dismiss()));
                ScrollView sv = new ScrollView(a);
                HorizontalScrollView hs = new HorizontalScrollView(a);
                TextView tv = new TextView(a);
                tv.setText(testo);
                tv.setTextIsSelectable(true);
                tv.setTextColor(t.testo);
                tv.setTypeface(Typeface.MONOSPACE);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, t.grandezzaTesto - 1);
                tv.setPadding(dp(12), dp(10), dp(12), dp(10));
                hs.addView(tv);
                sv.addView(hs);
                sv.setBackground(f.fondo(Tema.conAlfa(t.testo, 10), 12));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
                lp.topMargin = dp(12);
                c.addView(sv, lp);
                dl[0] = grande(c);
                dl[0].show();
            });
        });
    }

    // ------------------------------------------------------------ ARCHIVI

    /** Mostra il contenuto di un archivio compresso. */
    public void archivio(File file) {
        final Finestre.Progresso pr = f.progresso("Lettura dell'archivio…");
        lavoro.execute(() -> {
            List<Archivi.Voce> voci = null;
            String errore = null;
            try {
                voci = Archivi.elenca(file);
            } catch (Throwable e) {
                errore = "Non riesco a leggere questo archivio.\n" + (e.getMessage() != null ? e.getMessage() : e.toString())
                        + "\n\nPotrebbe essere protetto da password o danneggiato.";
            }
            pr.chiudi();
            final List<Archivi.Voce> lv = voci;
            final String err = errore;
            a.runOnUiThread(() -> {
                if (err != null) { f.avviso(file.getName(), err); return; }
                mostraArchivio(file, lv);
            });
        });
    }

    private void mostraArchivio(File file, List<Archivi.Voce> voci) {
        LinearLayout c = f.colonna();
        final Dialog[] dl = new Dialog[1];
        int nf = 0;
        long tot = 0;
        for (Archivi.Voce v : voci) if (!v.dir) { nf++; if (v.dimensione > 0) tot += v.dimensione; }
        c.addView(testata(file.getName(), nf + " file · " + OperazioniFile.leggibile(tot) + " estratti",
                () -> dl[0].dismiss()));

        ScrollView sv = new ScrollView(a);
        LinearLayout lista = f.colonna();
        sv.addView(lista);
        sv.setBackground(f.fondo(Tema.conAlfa(t.testo, 8), 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
        lp.topMargin = dp(12);
        c.addView(sv, lp);
        int mostrati = 0;
        for (final Archivi.Voce v : voci) {
            if (mostrati++ > 2000) break;
            LinearLayout r = new LinearLayout(a);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(12), dp(9), dp(12), dp(9));
            r.setBackground(f.tocco(0, 10));
            r.addView(new Disegni.IconaView(a, v.dir ? "cartella" : "documento", v.dir ? t.cartella : t.testo2),
                    new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView n = f.testo("  " + v.nome, t.grandezzaTesto, t.testo, false);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.START);
            r.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
            if (!v.dir && v.dimensione >= 0)
                r.addView(f.testo(OperazioniFile.leggibile(v.dimensione), t.grandezzaTesto - 2, t.testo2, false));
            if (!v.dir) r.setOnClickListener(x -> apriVoce(file, v.nome));
            lista.addView(r);
        }

        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.END);
        bar.setPadding(0, dp(12), 0, 0);
        TextView qui = f.pulsante("Estrai qui", false, x -> { dl[0].dismiss(); estrai(file, false); });
        TextView cart = f.pulsante("Estrai in una cartella", true, x -> { dl[0].dismiss(); estrai(file, true); });
        bar.addView(qui);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(-2, -2);
        l2.leftMargin = dp(8);
        bar.addView(cart, l2);
        TextView sugg = f.testo("Tocca un file per aprirlo", t.grandezzaTesto - 2, t.testo2, false);
        sugg.setPadding(dp(4), dp(6), 0, 0);
        c.addView(sugg);
        c.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        dl[0] = grande(c);
        dl[0].show();
    }

    /** Estrae un solo file in una cartella temporanea e lo apre. */
    private void apriVoce(File arch, String nome) {
        final Finestre.Progresso pr = f.progresso("Apertura…");
        lavoro.execute(() -> {
            File out = null;
            try {
                out = Archivi.estraiUno(arch, nome, a.getExternalCacheDir() != null ? a.getExternalCacheDir() : a.getCacheDir());
            } catch (Throwable ignored) { }
            pr.chiudi();
            final File o = out;
            a.runOnUiThread(() -> {
                if (o == null) { f.avviso("Attenzione", "Impossibile aprire questo file dall'archivio."); return; }
                a.apriQualsiasi(o);
            });
        });
    }

    /** Estrae tutto: nella stessa cartella o in una nuova cartella col nome dell'archivio. */
    public void estrai(File file, boolean inCartella) {
        File padre = file.getParentFile();
        File dest = padre;
        if (inCartella) {
            String base = file.getName();
            String lb = base.toLowerCase();
            for (String e : new String[]{".tar.gz", ".tar.bz2", ".tar.xz"})
                if (lb.endsWith(e)) { base = base.substring(0, base.length() - e.length()); lb = ""; break; }
            if (!lb.isEmpty() && base.lastIndexOf('.') > 0) base = base.substring(0, base.lastIndexOf('.'));
            dest = OperazioniFile.nomeLibero(padre, base);
        }
        final File d = dest;
        final Finestre.Progresso pr = f.progresso("Estrazione in corso");
        lavoro.execute(() -> {
            String err = null;
            int n = 0;
            try {
                n = Archivi.estraiTutto(file, d, new OperazioniFile.Avanzamento() {
                    @Override public void file(String nome) { pr.file(nome); }
                    @Override public boolean annullato() { return pr.annullato; }
                });
            } catch (Throwable e) {
                err = "Estrazione non riuscita: " + (e.getMessage() != null ? e.getMessage() : e.toString());
            }
            pr.chiudi();
            final String er = err;
            final int tot = n;
            a.runOnUiThread(() -> {
                a.ricarica();
                if (er != null) f.avviso("Attenzione", er);
                else a.avvisoBreve(tot + (tot == 1 ? " file estratto" : " file estratti")
                        + (d == padre ? "" : " in \"" + d.getName() + "\""));
            });
        });
    }

    /** Crea un archivio zip con i file scelti. */
    public void comprimi(List<File> fs) {
        if (fs.isEmpty()) return;
        File padre = fs.get(0).getParentFile();
        String nome = fs.size() == 1 ? fs.get(0).getName() + ".zip" : "Archivio.zip";
        f.chiedi("Comprimi in ZIP", OperazioniFile.nomeLibero(padre, nome).getName(), "Comprimi", true, n -> {
            if (n.isEmpty()) return;
            if (!n.toLowerCase().endsWith(".zip")) n = n + ".zip";
            File zip = OperazioniFile.nomeLibero(padre, n);
            final Finestre.Progresso pr = f.progresso("Compressione in corso");
            lavoro.execute(() -> {
                String err = null;
                try {
                    Archivi.comprimi(fs, zip, new OperazioniFile.Avanzamento() {
                        @Override public void file(String x) { pr.file(x); }
                        @Override public boolean annullato() { return pr.annullato; }
                    });
                    if (pr.annullato) zip.delete();
                } catch (Throwable e) {
                    err = "Compressione non riuscita: " + e.getMessage();
                    zip.delete();
                }
                pr.chiudi();
                final String er = err;
                a.runOnUiThread(() -> {
                    a.ricarica();
                    if (er != null) f.avviso("Attenzione", er);
                    else a.avvisoBreve("Creato \"" + zip.getName() + "\"");
                });
            });
        });
    }
}
