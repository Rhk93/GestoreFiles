package gestore;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * Legge ed estrae archivi compressi: zip, rar, 7z, tar, gz, tgz, bz2, xz. Crea archivi zip.
 */
public class Archivi {

    public static class Voce {
        public final String nome;
        public final boolean dir;
        public final long dimensione;
        Voce(String n, boolean d, long s) { nome = n; dir = d; dimensione = s; }
    }

    interface Contenuto { void scriviIn(OutputStream os) throws Exception; }
    interface PerVoce { boolean voce(String nome, boolean dir, long dim, Contenuto c) throws Exception; } // false = fermati

    public static boolean eArchivio(String est) {
        switch (est.toLowerCase()) {
            case "zip": case "jar": case "rar": case "7z": case "tar": case "gz": case "tgz":
            case "bz2": case "tbz": case "tbz2": case "xz": case "txz": case "cpio": case "ar":
                return true;
        }
        return false;
    }

    private static String minuscolo(File f) { return f.getName().toLowerCase(); }

    private static boolean tarCompresso(String n) {
        return n.endsWith(".tar.gz") || n.endsWith(".tgz") || n.endsWith(".tar.bz2") || n.endsWith(".tbz")
                || n.endsWith(".tbz2") || n.endsWith(".tar.xz") || n.endsWith(".txz");
    }

    private static void copia(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    /** Scorre tutte le voci dell'archivio. */
    private static void scorri(File f, PerVoce pv) throws Exception {
        String n = minuscolo(f);
        String est = OperazioniFile.estensione(n);

        if (est.equals("zip") || est.equals("jar")) {
            ZipFile zf;
            try { zf = new ZipFile(f, Charset.forName("UTF-8")); }
            catch (Exception e) { zf = new ZipFile(f, Charset.forName("CP437")); }
            try {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    final ZipEntry ze = en.nextElement();
                    final ZipFile z = zf;
                    if (!pv.voce(ze.getName(), ze.isDirectory(), ze.getSize(), os -> {
                        try (InputStream in = z.getInputStream(ze)) { copia(in, os); }
                    })) break;
                }
            } finally { zf.close(); }
            return;
        }

        if (est.equals("rar")) {
            com.github.junrar.Archive arc = new com.github.junrar.Archive(f);
            try {
                for (final com.github.junrar.rarfile.FileHeader fh : arc.getFileHeaders()) {
                    final com.github.junrar.Archive a = arc;
                    String nome = fh.getFileName().replace('\\', '/');
                    if (!pv.voce(nome, fh.isDirectory(), fh.getFullUnpackSize(), os -> a.extractFile(fh, os))) break;
                }
            } finally { arc.close(); }
            return;
        }

        if (est.equals("7z")) {
            SevenZFile sz = new SevenZFile(f);
            try {
                SevenZArchiveEntry e;
                while ((e = sz.getNextEntry()) != null) {
                    final SevenZFile s = sz;
                    if (!pv.voce(e.getName(), e.isDirectory(), e.isDirectory() ? 0 : e.getSize(), os -> {
                        byte[] b = new byte[64 * 1024];
                        int k;
                        while ((k = s.read(b, 0, b.length)) > 0) os.write(b, 0, k);
                    })) break;
                }
            } finally { sz.close(); }
            return;
        }

        InputStream in = new BufferedInputStream(new FileInputStream(f));
        try {
            boolean soloCompresso = est.equals("gz") || est.equals("bz2") || est.equals("xz")
                    || tarCompresso(n);
            if (soloCompresso) {
                InputStream dec = new BufferedInputStream(new CompressorStreamFactory().createCompressorInputStream(in));
                if (tarCompresso(n)) {
                    leggiArchivio(new TarArchiveInputStream(dec), pv);
                } else {
                    // un solo file compresso: "foto.jpg.gz" -> "foto.jpg"
                    String nome = f.getName().substring(0, f.getName().lastIndexOf('.'));
                    final InputStream d = dec;
                    pv.voce(nome, false, -1, os -> copia(d, os));
                }
            } else {
                leggiArchivio(new ArchiveStreamFactory().createArchiveInputStream(in), pv);
            }
        } finally { in.close(); }
    }

    private static void leggiArchivio(ArchiveInputStream ais, PerVoce pv) throws Exception {
        ArchiveEntry e;
        while ((e = ais.getNextEntry()) != null) {
            if (!ais.canReadEntryData(e)) continue;
            final ArchiveInputStream a = ais;
            if (!pv.voce(e.getName(), e.isDirectory(), e.getSize(), os -> copia(a, os))) break;
        }
    }

    /** Elenco del contenuto (max 5000 voci). */
    public static List<Voce> elenca(File f) throws Exception {
        final List<Voce> l = new ArrayList<>();
        scorri(f, (nome, dir, dim, c) -> {
            l.add(new Voce(nome, dir, dim));
            return l.size() < 5000;
        });
        return l;
    }

    /** File di destinazione sicuro (niente "../" fuori dalla cartella). */
    private static File destinazione(File cartella, String nome) throws IOException {
        File out = new File(cartella, nome);
        String base = cartella.getCanonicalPath() + File.separator;
        if (!out.getCanonicalPath().startsWith(base)) throw new IOException("Percorso non valido: " + nome);
        return out;
    }

    /** Estrae tutto in "cartella". Se un file esiste già, il nuovo prende un nome libero. */
    public static int estraiTutto(File f, File cartella, OperazioniFile.Avanzamento av) throws Exception {
        final int[] n = {0};
        cartella.mkdirs();
        scorri(f, (nome, dir, dim, c) -> {
            if (av != null && av.annullato()) return false;
            File out = destinazione(cartella, nome);
            if (dir) { out.mkdirs(); return true; }
            File p = out.getParentFile();
            if (p != null) p.mkdirs();
            if (out.exists()) out = OperazioniFile.nomeLibero(p, out.getName());
            if (av != null) av.file(nome);
            try (OutputStream os = new FileOutputStream(out)) { c.scriviIn(os); }
            n[0]++;
            return true;
        });
        return n[0];
    }

    /** Estrae un solo file (per aprirlo) nella cartella temporanea. */
    public static File estraiUno(File f, final String voce, File cartellaTemp) throws Exception {
        final File[] r = {null};
        File dest = new File(cartellaTemp, "anteprima");
        OperazioniFile.elimina(dest);
        dest.mkdirs();
        scorri(f, (nome, dir, dim, c) -> {
            if (!nome.equals(voce) || dir) return true;
            String solo = nome.substring(nome.lastIndexOf('/') + 1);
            File out = new File(dest, solo);
            try (OutputStream os = new FileOutputStream(out)) { c.scriviIn(os); }
            r[0] = out;
            return false;
        });
        return r[0];
    }

    // ------------------------------------------------------------ CREA ZIP

    public static void comprimi(List<File> fs, File zip, OperazioniFile.Avanzamento av) throws IOException {
        try (ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(zip))) {
            for (File f : fs) aggiungi(zo, f, f.getName(), av);
        }
    }

    private static void aggiungi(ZipOutputStream zo, File f, String nome, OperazioniFile.Avanzamento av) throws IOException {
        if (av != null && av.annullato()) return;
        if (f.isDirectory()) {
            zo.putNextEntry(new ZipEntry(nome + "/"));
            zo.closeEntry();
            File[] fs = f.listFiles();
            if (fs != null) for (File x : fs) aggiungi(zo, x, nome + "/" + x.getName(), av);
        } else {
            if (av != null) av.file(f.getName());
            ZipEntry ze = new ZipEntry(nome);
            ze.setTime(f.lastModified());
            zo.putNextEntry(ze);
            try (InputStream in = new FileInputStream(f)) { copia(in, zo); }
            zo.closeEntry();
        }
    }
}
