package gestore;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;

/**
 * Gestore Files - Copyright © Ignazio Paolicelli
 * Colori, carattere, grandezze e posizione della barra. Tutto salvato in memoria.
 */
public class Tema {

    public static final int SINISTRA = 0, SOPRA = 1, DESTRA = 2, SOTTO = 3;
    public static final String[] NOMI_POSIZIONE = {"Sinistra", "Sopra", "Destra", "Sotto"};

    // ---- Stili preimpostati: nome, sfondo, barra, testo, testo secondario, accento, cartelle, scheda file
    public static final String[] NOMI_STILI = {
            "Claude chiaro", "Claude scuro", "Mac", "Windows",
            "Notte", "Menta", "Lavanda", "Sabbia", "Oceano", "Rosa"
    };
    public static final int[][] STILI = {
            {0xFFF5F4EE, 0xFFFFFFFF, 0xFF1F1E1D, 0xFF6F6D66, 0xFFD97757, 0xFFDE8A68, 0xFFFFFFFF},
            {0xFF262624, 0xFF30302E, 0xFFF2F0E8, 0xFFA8A59C, 0xFFD97757, 0xFFD98C6A, 0xFF3A3A37},
            {0xFFF5F5F7, 0xFFFFFFFF, 0xFF1D1D1F, 0xFF6E6E73, 0xFF007AFF, 0xFF5EB4F3, 0xFFFFFFFF},
            {0xFFF3F3F3, 0xFFFFFFFF, 0xFF202020, 0xFF5F5F5F, 0xFF0067C0, 0xFFFFC83D, 0xFFFFFFFF},
            {0xFF14161B, 0xFF22262E, 0xFFE8EAED, 0xFF9AA0A6, 0xFF8AB4F8, 0xFF7FA8E8, 0xFF2A2F38},
            {0xFFEEF6F1, 0xFFFFFFFF, 0xFF17302A, 0xFF557066, 0xFF2E9E6A, 0xFF5CC08E, 0xFFFFFFFF},
            {0xFFF3F0FA, 0xFFFFFFFF, 0xFF2A2340, 0xFF6C6485, 0xFF7C5CD6, 0xFFA78BFA, 0xFFFFFFFF},
            {0xFFFAF6EF, 0xFFFFFFFF, 0xFF3B3226, 0xFF7A6E5E, 0xFFB5832F, 0xFFE0B45C, 0xFFFFFFFF},
            {0xFFEAF4FA, 0xFFFFFFFF, 0xFF0F2A3D, 0xFF4F6B7D, 0xFF0E7CB8, 0xFF3FA7D6, 0xFFFFFFFF},
            {0xFFFCF1F3, 0xFFFFFFFF, 0xFF3A1F27, 0xFF80606A, 0xFFD6547A, 0xFFF08CA8, 0xFFFFFFFF},
    };

    // ---- Caratteri disponibili
    public static final String[] NOMI_CARATTERI = {
            "Moderno", "Leggero", "Medio", "Stretto", "Classico", "Macchina da scrivere", "Informale", "Corsivo"
    };
    private static final String[] FAMIGLIE = {
            "sans-serif", "sans-serif-light", "sans-serif-medium", "sans-serif-condensed",
            "serif", "monospace", "casual", "cursive"
    };

    // ---- Valori correnti
    public int sfondo, barra, testo, testo2, accento, cartella, scheda;
    public int stile;            // indice stile preimpostato (-1 = personalizzato)
    public int carattere;        // indice carattere
    public int grandezzaTesto;   // sp
    public int grandezzaIcone;   // dp
    public int posizioneBarra;   // SINISTRA, SOPRA, DESTRA, SOTTO
    public int opacitaBarra;     // 30..100 (%)
    public boolean nascosti;     // mostra file nascosti
    public int ordine;           // 0 nome, 1 data, 2 dimensione, 3 tipo

    private final SharedPreferences sp;

    public Tema(Context c) {
        sp = c.getSharedPreferences("tema", Context.MODE_PRIVATE);
        carica();
    }

    public void carica() {
        stile = sp.getInt("stile", 0);
        int[] base = STILI[Math.max(0, Math.min(STILI.length - 1, stile < 0 ? 0 : stile))];
        sfondo = sp.getInt("sfondo", base[0]);
        barra = sp.getInt("barra", base[1]);
        testo = sp.getInt("testo", base[2]);
        testo2 = sp.getInt("testo2", base[3]);
        accento = sp.getInt("accento", base[4]);
        cartella = sp.getInt("cartella", base[5]);
        scheda = sp.getInt("scheda", base[6]);
        carattere = sp.getInt("carattere", 0);
        grandezzaTesto = sp.getInt("grandezzaTesto", 14);
        grandezzaIcone = sp.getInt("grandezzaIcone", 64);
        posizioneBarra = sp.getInt("posizioneBarra", SINISTRA);
        opacitaBarra = sp.getInt("opacitaBarra", 78);
        nascosti = sp.getBoolean("nascosti", false);
        ordine = sp.getInt("ordine", 0);
    }

    public void salva() {
        sp.edit()
                .putInt("stile", stile)
                .putInt("sfondo", sfondo).putInt("barra", barra)
                .putInt("testo", testo).putInt("testo2", testo2)
                .putInt("accento", accento).putInt("cartella", cartella)
                .putInt("scheda", scheda)
                .putInt("carattere", carattere)
                .putInt("grandezzaTesto", grandezzaTesto)
                .putInt("grandezzaIcone", grandezzaIcone)
                .putInt("posizioneBarra", posizioneBarra)
                .putInt("opacitaBarra", opacitaBarra)
                .putBoolean("nascosti", nascosti)
                .putInt("ordine", ordine)
                .apply();
    }

    public void applicaStile(int i) {
        int[] s = STILI[i];
        stile = i;
        sfondo = s[0]; barra = s[1]; testo = s[2]; testo2 = s[3];
        accento = s[4]; cartella = s[5]; scheda = s[6];
        salva();
    }

    public Typeface font() {
        int i = Math.max(0, Math.min(FAMIGLIE.length - 1, carattere));
        return Typeface.create(FAMIGLIE[i], Typeface.NORMAL);
    }

    public Typeface fontGrassetto() {
        int i = Math.max(0, Math.min(FAMIGLIE.length - 1, carattere));
        return Typeface.create(FAMIGLIE[i], Typeface.BOLD);
    }

    public static Typeface fontDi(int i) {
        return Typeface.create(FAMIGLIE[i], Typeface.NORMAL);
    }

    /** Colore della barra con l'opacità scelta. */
    public int barraTrasparente() {
        int a = Math.round(255f * opacitaBarra / 100f);
        return (barra & 0x00FFFFFF) | (a << 24);
    }

    public boolean scuro() {
        return luminosita(sfondo) < 0.5f;
    }

    public static float luminosita(int c) {
        return (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f;
    }

    public static int conAlfa(int c, int alfa) {
        return (c & 0x00FFFFFF) | (alfa << 24);
    }

    /** Mescola due colori: t=0 primo, t=1 secondo. */
    public static int mescola(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }
}
