package gestore;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * Disegna le icone: cartelle stile Mac, file con etichetta colorata e piccole icone a linea.
 */
public class Disegni {

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Path PATH = new Path();
    private static final RectF R = new RectF();

    // ------------------------------------------------------------ CARTELLA
    /** Cartella stile Mac/Windows centrata in (cx, cy), larga s. */
    public static void cartella(Canvas c, float cx, float cy, float s, int colore) {
        float w = s, h = s * 0.80f;
        float l = cx - w / 2f, t = cy - h / 2f, r = cx + w / 2f, b = cy + h / 2f;
        float rad = s * 0.07f;
        int scuro = Tema.mescola(colore, 0xFF000000, 0.18f);
        int chiaro = Tema.mescola(colore, 0xFFFFFFFF, 0.22f);

        P.setStyle(Paint.Style.FILL);
        // retro con linguetta
        P.setColor(scuro);
        PATH.reset();
        PATH.moveTo(l + rad, t);
        PATH.lineTo(l + w * 0.36f, t);
        PATH.lineTo(l + w * 0.44f, t + h * 0.12f);
        PATH.lineTo(r - rad, t + h * 0.12f);
        PATH.quadTo(r, t + h * 0.12f, r, t + h * 0.12f + rad);
        PATH.lineTo(r, b - rad);
        PATH.quadTo(r, b, r - rad, b);
        PATH.lineTo(l + rad, b);
        PATH.quadTo(l, b, l, b - rad);
        PATH.lineTo(l, t + rad);
        PATH.quadTo(l, t, l + rad, t);
        PATH.close();
        c.drawPath(PATH, P);

        // foglio che spunta
        P.setColor(0xFFFFFFFF);
        R.set(l + w * 0.07f, t + h * 0.20f, r - w * 0.07f, t + h * 0.50f);
        c.drawRoundRect(R, rad * 0.6f, rad * 0.6f, P);

        // fronte
        P.setColor(colore);
        R.set(l, t + h * 0.30f, r, b);
        c.drawRoundRect(R, rad, rad, P);

        // riflesso in alto
        P.setColor(chiaro);
        R.set(l, t + h * 0.30f, r, t + h * 0.30f + s * 0.035f);
        c.save();
        c.clipRect(R);
        R.set(l, t + h * 0.30f, r, b);
        c.drawRoundRect(R, rad, rad, P);
        c.restore();
    }

    // ------------------------------------------------------------ FILE
    /** Foglio con angolo piegato e etichetta dell'estensione. */
    public static void file(Canvas c, float cx, float cy, float s, String est, int scheda, int bordo, Typeface tf) {
        float w = s * 0.72f, h = s * 0.90f;
        float l = cx - w / 2f, t = cy - h / 2f, r = cx + w / 2f, b = cy + h / 2f;
        float piega = w * 0.28f, rad = s * 0.06f;

        PATH.reset();
        PATH.moveTo(l + rad, t);
        PATH.lineTo(r - piega, t);
        PATH.lineTo(r, t + piega);
        PATH.lineTo(r, b - rad);
        PATH.quadTo(r, b, r - rad, b);
        PATH.lineTo(l + rad, b);
        PATH.quadTo(l, b, l, b - rad);
        PATH.lineTo(l, t + rad);
        PATH.quadTo(l, t, l + rad, t);
        PATH.close();
        P.setStyle(Paint.Style.FILL);
        P.setColor(scheda);
        c.drawPath(PATH, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(Math.max(1.5f, s * 0.022f));
        P.setColor(Tema.conAlfa(bordo, 110));
        c.drawPath(PATH, P);

        // angolo piegato
        PATH.reset();
        PATH.moveTo(r - piega, t);
        PATH.lineTo(r - piega, t + piega - rad * 0.5f);
        PATH.quadTo(r - piega, t + piega, r - piega + rad * 0.5f, t + piega);
        PATH.lineTo(r, t + piega);
        P.setStyle(Paint.Style.FILL);
        P.setColor(Tema.conAlfa(bordo, 40));
        c.drawPath(PATH, P);
        P.setStyle(Paint.Style.STROKE);
        P.setColor(Tema.conAlfa(bordo, 110));
        c.drawPath(PATH, P);

        // righe di testo finte
        P.setStyle(Paint.Style.FILL);
        P.setColor(Tema.conAlfa(bordo, 50));
        float rh = s * 0.03f;
        for (int i = 0; i < 3; i++) {
            float y = t + h * (0.38f + i * 0.09f);
            R.set(l + w * 0.16f, y, r - w * (i == 2 ? 0.40f : 0.16f), y + rh);
            c.drawRoundRect(R, rh, rh, P);
        }

        // etichetta estensione
        String e = est == null || est.isEmpty() ? "" : est.toUpperCase();
        if (e.length() > 4) e = e.substring(0, 4);
        if (!e.isEmpty()) {
            int col = coloreEstensione(est);
            float bh = h * 0.22f;
            float bw = Math.min(w * 1.05f, Math.max(w * 0.62f, s * 0.16f * e.length() + s * 0.12f));
            R.set(cx - bw / 2f, b - h * 0.12f - bh, cx + bw / 2f, b - h * 0.12f);
            P.setColor(col);
            c.drawRoundRect(R, bh * 0.28f, bh * 0.28f, P);
            P.setColor(0xFFFFFFFF);
            P.setTypeface(Typeface.create(tf, Typeface.BOLD));
            P.setTextAlign(Paint.Align.CENTER);
            P.setTextSize(bh * 0.62f);
            Paint.FontMetrics fm = P.getFontMetrics();
            c.drawText(e, cx, R.centerY() - (fm.ascent + fm.descent) / 2f, P);
            P.setTextAlign(Paint.Align.LEFT);
        }
    }

    public static int coloreEstensione(String e) {
        if (e == null) return 0xFF8E8E93;
        switch (e.toLowerCase()) {
            case "pdf": return 0xFFE5484D;
            case "jpg": case "jpeg": case "png": case "gif": case "webp": case "bmp": case "heic": return 0xFF30A46C;
            case "mp3": case "wav": case "m4a": case "ogg": case "flac": case "aac": case "mid": case "midi": return 0xFF8E4EC6;
            case "mp4": case "mkv": case "avi": case "mov": case "3gp": case "webm": return 0xFFD6409F;
            case "zip": case "rar": case "7z": case "tar": case "gz": return 0xFFA0703C;
            case "apk": return 0xFF3DAA55;
            case "doc": case "docx": case "odt": case "rtf": return 0xFF2B6CD4;
            case "xls": case "xlsx": case "ods": case "csv": return 0xFF1E8E3E;
            case "ppt": case "pptx": case "odp": return 0xFFE5732B;
            case "txt": case "md": case "log": return 0xFF6E7681;
            case "html": case "htm": case "js": case "css": case "json": case "xml": case "java": return 0xFF0E8A9E;
            case "gp": case "gp5": case "gpx": case "mscz": case "mxl": case "musicxml": return 0xFFB5832F;
            default: return 0xFF8E8E93;
        }
    }

    // ------------------------------------------------------------ ICONE A LINEA
    /** Piccole icone a linea per la barra e i pulsanti. */
    public static void icona(Canvas c, String tipo, float cx, float cy, float s, int colore) {
        P.setColor(colore);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(Math.max(2f, s * 0.085f));
        P.setStrokeCap(Paint.Cap.ROUND);
        P.setStrokeJoin(Paint.Join.ROUND);
        float h = s / 2f;
        float l = cx - h, t = cy - h, r = cx + h, b = cy + h;
        PATH.reset();
        switch (tipo) {
            case "casa":
                PATH.moveTo(l + s * 0.08f, cy - s * 0.02f);
                PATH.lineTo(cx, t + s * 0.1f);
                PATH.lineTo(r - s * 0.08f, cy - s * 0.02f);
                c.drawPath(PATH, P);
                PATH.reset();
                PATH.moveTo(l + s * 0.2f, cy - s * 0.12f);
                PATH.lineTo(l + s * 0.2f, b - s * 0.1f);
                PATH.lineTo(r - s * 0.2f, b - s * 0.1f);
                PATH.lineTo(r - s * 0.2f, cy - s * 0.12f);
                c.drawPath(PATH, P);
                c.drawLine(cx, b - s * 0.1f, cx, cy + s * 0.15f, P);
                break;
            case "download":
                c.drawLine(cx, t + s * 0.1f, cx, cy + s * 0.15f, P);
                PATH.moveTo(cx - s * 0.2f, cy - s * 0.05f);
                PATH.lineTo(cx, cy + s * 0.15f);
                PATH.lineTo(cx + s * 0.2f, cy - s * 0.05f);
                c.drawPath(PATH, P);
                c.drawLine(l + s * 0.15f, b - s * 0.12f, r - s * 0.15f, b - s * 0.12f, P);
                break;
            case "documento":
                R.set(l + s * 0.2f, t + s * 0.08f, r - s * 0.2f, b - s * 0.08f);
                c.drawRoundRect(R, s * 0.08f, s * 0.08f, P);
                c.drawLine(l + s * 0.33f, cy - s * 0.15f, r - s * 0.33f, cy - s * 0.15f, P);
                c.drawLine(l + s * 0.33f, cy, r - s * 0.33f, cy, P);
                c.drawLine(l + s * 0.33f, cy + s * 0.15f, cx, cy + s * 0.15f, P);
                break;
            case "immagine":
                R.set(l + s * 0.1f, t + s * 0.18f, r - s * 0.1f, b - s * 0.18f);
                c.drawRoundRect(R, s * 0.08f, s * 0.08f, P);
                PATH.moveTo(l + s * 0.18f, b - s * 0.26f);
                PATH.lineTo(cx - s * 0.08f, cy - s * 0.02f);
                PATH.lineTo(cx + s * 0.08f, cy + s * 0.12f);
                PATH.lineTo(cx + s * 0.18f, cy + s * 0.04f);
                PATH.lineTo(r - s * 0.16f, b - s * 0.26f);
                c.drawPath(PATH, P);
                c.drawCircle(cx + s * 0.16f, cy - s * 0.12f, s * 0.05f, P);
                break;
            case "foto":
                R.set(l + s * 0.08f, t + s * 0.25f, r - s * 0.08f, b - s * 0.15f);
                c.drawRoundRect(R, s * 0.1f, s * 0.1f, P);
                c.drawLine(cx - s * 0.12f, t + s * 0.15f, cx + s * 0.12f, t + s * 0.15f, P);
                c.drawCircle(cx, cy + s * 0.05f, s * 0.14f, P);
                break;
            case "musica":
                c.drawLine(cx + s * 0.12f, t + s * 0.12f, cx + s * 0.12f, b - s * 0.25f, P);
                PATH.moveTo(cx + s * 0.12f, t + s * 0.12f);
                PATH.quadTo(cx + s * 0.32f, t + s * 0.2f, cx + s * 0.3f, cy - s * 0.05f);
                c.drawPath(PATH, P);
                P.setStyle(Paint.Style.FILL);
                c.drawOval(cx - s * 0.22f, b - s * 0.35f, cx + s * 0.14f, b - s * 0.12f, P);
                break;
            case "video":
                R.set(l + s * 0.08f, t + s * 0.2f, r - s * 0.08f, b - s * 0.2f);
                c.drawRoundRect(R, s * 0.1f, s * 0.1f, P);
                P.setStyle(Paint.Style.FILL);
                PATH.moveTo(cx - s * 0.08f, cy - s * 0.13f);
                PATH.lineTo(cx + s * 0.14f, cy);
                PATH.lineTo(cx - s * 0.08f, cy + s * 0.13f);
                PATH.close();
                c.drawPath(PATH, P);
                break;
            case "sd":
                PATH.moveTo(l + s * 0.4f, t + s * 0.1f);
                PATH.lineTo(r - s * 0.2f, t + s * 0.1f);
                PATH.lineTo(r - s * 0.2f, b - s * 0.1f);
                PATH.lineTo(l + s * 0.2f, b - s * 0.1f);
                PATH.lineTo(l + s * 0.2f, t + s * 0.3f);
                PATH.close();
                c.drawPath(PATH, P);
                c.drawLine(cx - s * 0.05f, t + s * 0.22f, cx - s * 0.05f, t + s * 0.34f, P);
                c.drawLine(cx + s * 0.1f, t + s * 0.22f, cx + s * 0.1f, t + s * 0.34f, P);
                break;
            case "stella": {
                for (int i = 0; i < 10; i++) {
                    double a = Math.PI / 2 + i * Math.PI / 5;
                    float rr = (i % 2 == 0) ? s * 0.42f : s * 0.18f;
                    float x = cx + (float) (Math.cos(a) * rr), y = cy - (float) (Math.sin(a) * rr) + s * 0.03f;
                    if (i == 0) PATH.moveTo(x, y); else PATH.lineTo(x, y);
                }
                PATH.close();
                c.drawPath(PATH, P);
                break;
            }
            case "impostazioni": {
                c.drawCircle(cx, cy, s * 0.14f, P);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    float x1 = cx + (float) Math.cos(a) * s * 0.26f, y1 = cy + (float) Math.sin(a) * s * 0.26f;
                    float x2 = cx + (float) Math.cos(a) * s * 0.38f, y2 = cy + (float) Math.sin(a) * s * 0.38f;
                    c.drawLine(x1, y1, x2, y2, P);
                }
                c.drawCircle(cx, cy, s * 0.26f, P);
                break;
            }
            case "nuova":
                PATH.moveTo(l + s * 0.1f, t + s * 0.25f);
                PATH.lineTo(l + s * 0.38f, t + s * 0.25f);
                PATH.lineTo(l + s * 0.46f, t + s * 0.33f);
                PATH.lineTo(r - s * 0.1f, t + s * 0.33f);
                PATH.lineTo(r - s * 0.1f, b - s * 0.15f);
                PATH.lineTo(l + s * 0.1f, b - s * 0.15f);
                PATH.close();
                c.drawPath(PATH, P);
                c.drawLine(cx, cy - s * 0.05f, cx, cy + s * 0.23f, P);
                c.drawLine(cx - s * 0.14f, cy + s * 0.09f, cx + s * 0.14f, cy + s * 0.09f, P);
                break;
            case "incolla":
                R.set(l + s * 0.18f, t + s * 0.16f, r - s * 0.18f, b - s * 0.08f);
                c.drawRoundRect(R, s * 0.08f, s * 0.08f, P);
                R.set(cx - s * 0.13f, t + s * 0.08f, cx + s * 0.13f, t + s * 0.24f);
                c.drawRoundRect(R, s * 0.05f, s * 0.05f, P);
                c.drawLine(l + s * 0.33f, cy + s * 0.05f, r - s * 0.33f, cy + s * 0.05f, P);
                c.drawLine(l + s * 0.33f, cy + s * 0.2f, cx, cy + s * 0.2f, P);
                break;
            case "riordina": {
                float q = s * 0.26f, g = s * 0.1f;
                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < 2; j++) {
                        float x = cx - q - g / 2f + i * (q + g), y = cy - q - g / 2f + j * (q + g);
                        R.set(x, y, x + q, y + q);
                        c.drawRoundRect(R, s * 0.06f, s * 0.06f, P);
                    }
                break;
            }
            case "indietro":
                PATH.moveTo(cx + s * 0.1f, t + s * 0.2f);
                PATH.lineTo(cx - s * 0.15f, cy);
                PATH.lineTo(cx + s * 0.1f, b - s * 0.2f);
                c.drawPath(PATH, P);
                break;
            case "avanti":
                PATH.moveTo(cx - s * 0.1f, t + s * 0.2f);
                PATH.lineTo(cx + s * 0.15f, cy);
                PATH.lineTo(cx - s * 0.1f, b - s * 0.2f);
                c.drawPath(PATH, P);
                break;
            case "su":
                PATH.moveTo(l + s * 0.2f, cy + s * 0.1f);
                PATH.lineTo(cx, cy - s * 0.15f);
                PATH.lineTo(r - s * 0.2f, cy + s * 0.1f);
                c.drawPath(PATH, P);
                break;
            case "menu":
                P.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy - s * 0.25f, s * 0.07f, P);
                c.drawCircle(cx, cy, s * 0.07f, P);
                c.drawCircle(cx, cy + s * 0.25f, s * 0.07f, P);
                break;
            case "elenco":
                for (int i = -1; i <= 1; i++) {
                    float y = cy + i * s * 0.25f;
                    c.drawLine(l + s * 0.38f, y, r - s * 0.12f, y, P);
                    c.drawPoint(l + s * 0.18f, y, P);
                }
                break;
            case "comprimi":
                R.set(l + s * 0.1f, t + s * 0.15f, r - s * 0.1f, b - s * 0.15f);
                c.drawRoundRect(R, s * 0.08f, s * 0.08f, P);
                c.drawLine(l + s * 0.38f, t + s * 0.15f, l + s * 0.38f, b - s * 0.15f, P);
                break;
            case "chiudi":
                c.drawLine(l + s * 0.25f, t + s * 0.25f, r - s * 0.25f, b - s * 0.25f, P);
                c.drawLine(r - s * 0.25f, t + s * 0.25f, l + s * 0.25f, b - s * 0.25f, P);
                break;
            case "aggiorna":
                R.set(l + s * 0.18f, t + s * 0.18f, r - s * 0.18f, b - s * 0.18f);
                c.drawArc(R, -60, 290, false, P);
                PATH.moveTo(r - s * 0.3f, t + s * 0.12f);
                PATH.lineTo(r - s * 0.2f, t + s * 0.28f);
                PATH.lineTo(r - s * 0.38f, t + s * 0.32f);
                c.drawPath(PATH, P);
                break;
            case "cartella":
            default:
                PATH.moveTo(l + s * 0.1f, t + s * 0.22f);
                PATH.lineTo(l + s * 0.38f, t + s * 0.22f);
                PATH.lineTo(l + s * 0.46f, t + s * 0.31f);
                PATH.lineTo(r - s * 0.1f, t + s * 0.31f);
                PATH.lineTo(r - s * 0.1f, b - s * 0.18f);
                PATH.lineTo(l + s * 0.1f, b - s * 0.18f);
                PATH.close();
                c.drawPath(PATH, P);
                break;
        }
        P.setStyle(Paint.Style.FILL);
    }

    /** View che mostra una icona a linea. */
    public static class IconaView extends View {
        String tipo;
        int colore;

        public IconaView(Context c, String tipo, int colore) {
            super(c);
            this.tipo = tipo;
            this.colore = colore;
        }

        public void imposta(String tipo, int colore) {
            this.tipo = tipo;
            this.colore = colore;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            icona(c, tipo, getWidth() / 2f, getHeight() / 2f, s, colore);
        }
    }

    /** View che mostra una piccola cartella colorata (logo nella barra). */
    public static class LogoView extends View {
        int colore;

        public LogoView(Context c, int colore) {
            super(c);
            this.colore = colore;
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()) * 0.9f;
            cartella(c, getWidth() / 2f, getHeight() / 2f, s, colore);
        }
    }
}
