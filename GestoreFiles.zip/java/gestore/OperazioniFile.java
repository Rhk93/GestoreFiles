package gestore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * Copia, sposta, elimina, nomi unici e dimensioni leggibili.
 */
public class OperazioniFile {

    public interface Avanzamento {
        void file(String nome);
        boolean annullato();
    }

    /** Trova un nome libero nella cartella: "foto.jpg" -> "foto (2).jpg". */
    public static File nomeLibero(File cartella, String nome) {
        File f = new File(cartella, nome);
        if (!f.exists()) return f;
        String base = nome, est = "";
        int p = nome.lastIndexOf('.');
        if (p > 0) { base = nome.substring(0, p); est = nome.substring(p); }
        for (int i = 2; i < 10000; i++) {
            f = new File(cartella, base + " (" + i + ")" + est);
            if (!f.exists()) return f;
        }
        return new File(cartella, base + " " + System.currentTimeMillis() + est);
    }

    /** true se 'figlio' è dentro (o uguale a) 'padre'. */
    public static boolean dentro(File figlio, File padre) {
        String a = figlio.getAbsolutePath(), b = padre.getAbsolutePath();
        return a.equals(b) || a.startsWith(b + "/");
    }

    public static void copia(File da, File a, Avanzamento av) throws IOException {
        if (av != null && av.annullato()) return;
        if (da.isDirectory()) {
            if (!a.exists() && !a.mkdirs()) throw new IOException("Impossibile creare " + a.getName());
            File[] fs = da.listFiles();
            if (fs != null) for (File f : fs) copia(f, new File(a, f.getName()), av);
        } else {
            if (av != null) av.file(da.getName());
            try (InputStream in = new FileInputStream(da); OutputStream out = new FileOutputStream(a)) {
                byte[] buf = new byte[256 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (av != null && av.annullato()) break;
                    out.write(buf, 0, n);
                }
            }
            a.setLastModified(da.lastModified());
        }
    }

    public static void sposta(File da, File a, Avanzamento av) throws IOException {
        if (da.renameTo(a)) return;           // stesso disco: istantaneo
        copia(da, a, av);                     // disco diverso (es. scheda SD)
        if (av == null || !av.annullato()) elimina(da);
    }

    public static boolean elimina(File f) {
        if (f.isDirectory()) {
            File[] fs = f.listFiles();
            if (fs != null) for (File x : fs) elimina(x);
        }
        return f.delete();
    }

    public static long dimensione(File f) {
        if (!f.isDirectory()) return f.length();
        long t = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) t += dimensione(x);
        return t;
    }

    public static int conta(File f) {
        if (!f.isDirectory()) return 1;
        int t = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) t += conta(x);
        return t;
    }

    public static String leggibile(long b) {
        if (b < 1024) return b + " B";
        String[] u = {"KB", "MB", "GB", "TB"};
        double v = b;
        int i = -1;
        do { v /= 1024; i++; } while (v >= 1024 && i < u.length - 1);
        return new DecimalFormat(v < 10 ? "0.0" : "0").format(v) + " " + u[i];
    }

    public static String estensione(String nome) {
        int p = nome.lastIndexOf('.');
        return (p > 0 && p < nome.length() - 1) ? nome.substring(p + 1) : "";
    }

    public static boolean immagine(String est) {
        switch (est.toLowerCase()) {
            case "jpg": case "jpeg": case "png": case "webp": case "gif": case "bmp": case "heic":
                return true;
        }
        return false;
    }
}
