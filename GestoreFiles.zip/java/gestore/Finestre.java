package gestore;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Gestore Files - Copyright © Ignazio Paolicelli
 * Finestre e menu con la stessa grafica dell'app (angoli arrotondati, colori del tema).
 */
public class Finestre {

    public interface Scelta { void scelto(int i); }
    public interface Testo { void ok(String s); }

    private final Activity a;
    private final Tema t;
    /** Se impostato, il prossimo menu si apre vicino a questo rettangolo (coordinate dello schermo). */
    public android.graphics.RectF ancora;

    public Finestre(Activity a, Tema t) {
        this.a = a;
        this.t = t;
    }

    int dp(float v) {
        return Math.round(v * a.getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------ mattoncini grafici

    public GradientDrawable fondo(int colore, float raggioDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(colore);
        g.setCornerRadius(dp(raggioDp));
        return g;
    }

    public Drawable tocco(int coloreFondo, float raggioDp) {
        GradientDrawable mask = fondo(Color.WHITE, raggioDp);
        Drawable base = coloreFondo == 0 ? null : fondo(coloreFondo, raggioDp);
        return new RippleDrawable(ColorStateList.valueOf(Tema.conAlfa(t.accento, 60)), base, mask);
    }

    public TextView testo(String s, float spIn, int colore, boolean grassetto) {
        TextView tv = new TextView(a);
        tv.setText(s);
        tv.setTextColor(colore);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, spIn);
        tv.setTypeface(grassetto ? t.fontGrassetto() : t.font());
        return tv;
    }

    public TextView pulsante(String s, boolean principale, View.OnClickListener cl) {
        TextView b = testo(s, t.grandezzaTesto + 1, principale ? Color.WHITE : t.testo, principale);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(10), dp(18), dp(10));
        b.setBackground(tocco(principale ? t.accento : Tema.conAlfa(t.testo, 18), 12));
        b.setOnClickListener(cl);
        return b;
    }

    /** Crea una finestra vuota con lo sfondo arrotondato; restituisce il contenitore. */
    public Dialog nuova(LinearLayout contenuto, float larghezzaMaxDp) {
        Dialog dl = new Dialog(a);
        dl.requestWindowFeature(Window.FEATURE_NO_TITLE);
        contenuto.setBackground(fondo(t.barra, 22));
        contenuto.setPadding(dp(20), dp(18), dp(20), dp(16));
        dl.setContentView(contenuto);
        Window w = dl.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = a.getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min((int) (sw * 0.92f), dp(larghezzaMaxDp)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setDimAmount(0.25f);
        }
        return dl;
    }

    public LinearLayout colonna() {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    // ------------------------------------------------------------ menu

    /** Menu a lista. icone può essere null. */
    public void menu(String titolo, String[] voci, String[] icone, Scelta s) {
        LinearLayout c = colonna();
        if (titolo != null) {
            TextView ti = testo(titolo, t.grandezzaTesto + 3, t.testo, true);
            ti.setSingleLine(true);
            ti.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            ti.setPadding(dp(6), 0, dp(6), dp(10));
            c.addView(ti);
        }
        LinearLayout lista = colonna();
        ScrollView sv = new ScrollView(a);
        sv.addView(lista);
        c.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final android.graphics.RectF vicino = ancora;
        ancora = null;
        final Dialog dl = nuova(c, vicino != null ? 290 : 380);
        for (int i = 0; i < voci.length; i++) {
            final int k = i;
            LinearLayout riga = new LinearLayout(a);
            riga.setOrientation(LinearLayout.HORIZONTAL);
            riga.setGravity(Gravity.CENTER_VERTICAL);
            riga.setPadding(dp(10), dp(11), dp(10), dp(11));
            riga.setBackground(tocco(0, 12));
            boolean pericolo = voci[i].startsWith("Elimina");
            int col = pericolo ? 0xFFE5484D : t.testo;
            if (icone != null && icone[i] != null) {
                Disegni.IconaView iv = new Disegni.IconaView(a, icone[i], pericolo ? col : t.testo2);
                riga.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));
                View sp = new View(a);
                riga.addView(sp, new LinearLayout.LayoutParams(dp(14), 1));
            }
            riga.addView(testo(voci[i], t.grandezzaTesto + 1, col, false));
            riga.setOnClickListener(v -> {
                dl.dismiss();
                s.scelto(k);
            });
            lista.addView(riga);
        }
        if (vicino != null) posizionaVicino(dl, c, vicino);
        dl.show();
    }

    /** Mette il menu accanto alla cartella: a destra se c'è spazio, altrimenti a sinistra. */
    private void posizionaVicino(Dialog dl, View contenuto, android.graphics.RectF r) {
        Window w = dl.getWindow();
        if (w == null) return;
        android.util.DisplayMetrics dm = a.getResources().getDisplayMetrics();
        int sw = dm.widthPixels, sh = dm.heightPixels;
        int m = dp(10), spazio = dp(8);
        int barraStato = 0;
        int id = a.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (id > 0) barraStato = a.getResources().getDimensionPixelSize(id);
        int larg = Math.min((int) (sw * 0.92f), dp(290));
        contenuto.measure(View.MeasureSpec.makeMeasureSpec(larg, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST));
        int alt = Math.min(contenuto.getMeasuredHeight(), sh - barraStato - 2 * m);

        int x;
        if (r.right + spazio + larg <= sw - m) x = (int) (r.right + spazio);
        else if (r.left - spazio - larg >= m) x = (int) (r.left - spazio - larg);
        else x = (int) Math.max(m, Math.min(sw - m - larg, r.centerX() - larg / 2f));
        int y = (int) r.top;
        y = Math.max(barraStato + m, Math.min(sh - m - alt, y));

        w.setGravity(Gravity.TOP | Gravity.START);
        w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.x = x;
        lp.y = y;
        lp.width = larg;
        lp.height = alt < contenuto.getMeasuredHeight() ? alt : ViewGroup.LayoutParams.WRAP_CONTENT;
        lp.dimAmount = 0.12f;
        w.setAttributes(lp);
    }

    // ------------------------------------------------------------ conferma / avviso

    public void conferma(String titolo, String messaggio, String[] bottoni, Scelta s) {
        LinearLayout c = colonna();
        c.addView(testo(titolo, t.grandezzaTesto + 4, t.testo, true));
        if (messaggio != null) {
            TextView m = testo(messaggio, t.grandezzaTesto + 1, t.testo2, false);
            m.setPadding(0, dp(10), 0, dp(6));
            c.addView(m);
        }
        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.END);
        bar.setPadding(0, dp(14), 0, 0);
        c.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        final Dialog dl = nuova(c, 440);
        if (s != null) dl.setOnCancelListener(x -> s.scelto(bottoni.length - 1));
        for (int i = bottoni.length - 1; i >= 0; i--) {
            final int k = i;
            TextView b = pulsante(bottoni[i], i == 0, v -> {
                dl.dismiss();
                if (s != null) s.scelto(k);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(8);
            bar.addView(b, lp);
        }
        dl.show();
    }

    public void avviso(String titolo, String messaggio) {
        conferma(titolo, messaggio, new String[]{"OK"}, null);
    }

    // ------------------------------------------------------------ inserimento testo

    public void chiedi(String titolo, String iniziale, String ok, boolean selezionaSenzaEstensione, Testo cb) {
        LinearLayout c = colonna();
        c.addView(testo(titolo, t.grandezzaTesto + 4, t.testo, true));
        final EditText et = new EditText(a);
        et.setText(iniziale);
        et.setTextColor(t.testo);
        et.setTypeface(t.font());
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, t.grandezzaTesto + 2);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setBackground(fondo(Tema.conAlfa(t.testo, 14), 12));
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        c.addView(et, lp);
        int fine = iniziale.length();
        if (selezionaSenzaEstensione) {
            int p = iniziale.lastIndexOf('.');
            if (p > 0) fine = p;
        }
        et.setSelection(0, fine);

        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.END);
        bar.setPadding(0, dp(16), 0, 0);
        c.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        final Dialog dl = nuova(c, 440);
        TextView an = pulsante("Annulla", false, v -> dl.dismiss());
        TextView okb = pulsante(ok, true, v -> {
            String s = et.getText().toString().trim();
            dl.dismiss();
            cb.ok(s);
        });
        bar.addView(an);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
        lp2.leftMargin = dp(8);
        bar.addView(okb, lp2);
        Window w = dl.getWindow();
        if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dl.show();
        et.requestFocus();
        et.postDelayed(() -> {
            InputMethodManager im = (InputMethodManager) a.getSystemService(Activity.INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
        }, 150);
    }

    // ------------------------------------------------------------ avanzamento

    public class Progresso {
        public final Dialog dl;
        final TextView riga;
        public volatile boolean annullato;

        Progresso(String titolo) {
            LinearLayout c = colonna();
            c.addView(testo(titolo, t.grandezzaTesto + 4, t.testo, true));
            riga = testo("…", t.grandezzaTesto, t.testo2, false);
            riga.setSingleLine(true);
            riga.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            riga.setPadding(0, dp(10), 0, dp(4));
            c.addView(riga);
            android.widget.ProgressBar pb = new android.widget.ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
            pb.setIndeterminate(true);
            pb.setIndeterminateTintList(ColorStateList.valueOf(t.accento));
            c.addView(pb, new LinearLayout.LayoutParams(-1, dp(18)));
            LinearLayout bar = new LinearLayout(a);
            bar.setGravity(Gravity.END);
            bar.setPadding(0, dp(12), 0, 0);
            c.addView(bar, new LinearLayout.LayoutParams(-1, -2));
            dl = nuova(c, 440);
            dl.setCancelable(false);
            bar.addView(pulsante("Annulla", false, v -> {
                annullato = true;
                riga.setText("Annullamento…");
            }));
            dl.show();
        }

        public void file(String nome) {
            a.runOnUiThread(() -> riga.setText(nome));
        }

        public void chiudi() {
            a.runOnUiThread(() -> {
                try { dl.dismiss(); } catch (Exception ignored) { }
            });
        }
    }

    public Progresso progresso(String titolo) {
        return new Progresso(titolo);
    }
}
