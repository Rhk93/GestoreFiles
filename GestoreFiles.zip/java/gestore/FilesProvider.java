package gestore;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Gestore Files - Copyright © Ignazio Paolicelli
 * Permette alle altre app (lettori PDF, galleria, musica...) di aprire i file scelti.
 */
public class FilesProvider extends ContentProvider {

    public static final String AUTORITA = "it.paolicelli.gestorefiles.files";

    public static Uri uriDi(File f) {
        return new Uri.Builder().scheme("content").authority(AUTORITA).path(f.getAbsolutePath()).build();
    }

    public static String mime(File f) {
        String n = f.getName();
        int p = n.lastIndexOf('.');
        if (p >= 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substring(p + 1).toLowerCase());
            if (m != null) return m;
        }
        return "*/*";
    }

    private File fileDi(Uri u) {
        return new File(u.getPath());
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public String getType(Uri uri) {
        String m = mime(fileDi(uri));
        return "*/*".equals(m) ? "application/octet-stream" : m;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = fileDi(uri);
        if (!f.exists()) throw new FileNotFoundException(f.getAbsolutePath());
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File f = fileDi(uri);
        String[] col = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor mc = new MatrixCursor(col, 1);
        Object[] riga = new Object[col.length];
        for (int i = 0; i < col.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(col[i])) riga[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(col[i])) riga[i] = f.length();
            else riga[i] = null;
        }
        mc.addRow(riga);
        return mc;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
