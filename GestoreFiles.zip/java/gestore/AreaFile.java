package gestore;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.OverScroller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Gestore File - Copyright © Ignazio Paolicelli
 * L'area dove stanno le cartelle: si spostano col dito dove si vuole,
 * si aprono con un tocco, tenendo premuto si apre il menu, "Riordina" le mette in fila.
 */
public class AreaFile extends View {

    public interface Ascoltatore {
        void tocco(Elemento e);
        void doppioTocco(Elemento e);
        void pressione(Elemento e);                                  // e == null: area vuota
        void rilasciaSu(List<Elemento> trascinati, Elemento cartella);
        void posizioniCambiate();
    }

    public static class Elemento {
        public File file;
        public boolean dir;
        public String nome, est;
        public float x, y;            // px, relativi all'origine dell'area
        float ax, ay, bx, by;         // per l'animazione
        public boolean sel;
        boolean piazzato;
        StaticLayout lay;
        String info;
        int layLarghezza;

        public Elemento(File f) {
            file = f;
            dir = f.isDirectory();
            nome = f.getName();
            est = dir ? "" : OperazioniFile.estensione(nome);
        }
    }

    private final Tema tema;
    private final float d;           // densità
    private Ascoltatore asc;
    public final List<Elemento> elementi = new ArrayList<>();
    private String messaggio = "";

    // margini interni (spazio per barra e intestazione)
    private float insL, insT, insR, insB;
    private float scrollY;

    // misure
    private float iconaPx, cellaW, cellaH, spazio;
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rr = new RectF();
    private final Path clip = new Path();

    // tocco
    private final Handler h = new Handler(Looper.getMainLooper());
    private final int slop;
    private float downX, downY, scrollAlDown;
    private Elemento premuto;
    private boolean mosso, lungoFatto, trascina;
    private final List<Elemento> trascinati = new ArrayList<>();
    private final Map<Elemento, float[]> inizio = new HashMap<>();
    private Elemento bersaglio;
    private VelocityTracker vt;
    private final OverScroller scroller;
    private boolean layoutInAttesa;
    private ValueAnimator anim;
    private final List<Elemento> elenco = new ArrayList<>();   // ordine per la vista elenco
    private boolean soloScorri;   // due dita / trackpad: la pagina scorre, le cartelle non si spostano
    private Elemento ultimoTocco;
    private long tempoUltimo;

    // miniature immagini
    private static final LruCache<String, Bitmap> MINI = new LruCache<String, Bitmap>(
            (int) Math.min(48L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 6)) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };
    private static final ExecutorService ES = Executors.newFixedThreadPool(2);
    private final Set<String> inCarico = new HashSet<>();

    private final Runnable lungo = new Runnable() {
        @Override
        public void run() {
            if (mosso) return;
            lungoFatto = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            if (asc != null) asc.pressione(premuto);
        }
    };

    public AreaFile(Context c, Tema t) {
        super(c);
        tema = t;
        d = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        scroller = new OverScroller(c);
        aggiornaMisure();
    }

    public void setAscoltatore(Ascoltatore a) {
        asc = a;
    }

    public void setMessaggio(String m) {
        messaggio = m == null ? "" : m;
        invalidate();
    }

    public void setMargini(float l, float t, float r, float b) {
        insL = l; insT = t; insR = r; insB = b;
        limitaPosizioni();
        limitaScroll();
        invalidate();
    }

    /** Ricalcola dimensioni dopo un cambio di tema/carattere/grandezza. */
    public void aggiornaMisure() {
        float vecchioX = cellaW + spazio, vecchioY = cellaH + spazio;
        iconaPx = tema.grandezzaIcone * d;
        tp.setTypeface(tema.font());
        tp.setTextSize(tema.grandezzaTesto * getResources().getDisplayMetrics().scaledDensity);
        cellaW = Math.max(iconaPx * 1.7f, 84 * d);
        float riga = tp.getFontSpacing();
        cellaH = 8 * d + iconaPx + 6 * d + riga * 2 + 8 * d;
        spazio = 10 * d;
        // le cartelle mantengono la stessa disposizione anche se cambiano le grandezze
        if (vecchioX > 0 && vecchioY > 0) {
            float fx = (cellaW + spazio) / vecchioX, fy = (cellaH + spazio) / vecchioY;
            for (Elemento e : elementi) { e.x *= fx; e.y *= fy; }
        }
        for (Elemento e : elementi) e.lay = null;
        limitaPosizioni();
        limitaScroll();
        invalidate();
    }

    public float dp(float v) {
        return v * d;
    }

    // ------------------------------------------------------------ CARICAMENTO

    /** Imposta gli elementi; posizioni = nome -> {colonna, riga} (anche con decimali), salvate in precedenza. */
    public void setElementi(List<Elemento> lista, Map<String, float[]> posizioni, boolean tienScroll) {
        if (anim != null) anim.cancel();
        elementi.clear();
        elementi.addAll(lista);
        elenco.clear();
        elenco.addAll(lista);
        if (!tienScroll) scrollY = 0;
        boolean qualcuno = false;
        for (Elemento e : elementi) {
            float[] pos = posizioni != null ? posizioni.get(e.nome) : null;
            if (pos != null) {
                e.x = pos[0] * (cellaW + spazio);
                e.y = pos[1] * (cellaH + spazio);
                e.piazzato = true;
                qualcuno = true;
            } else e.piazzato = false;
        }
        if (getWidth() == 0) {
            layoutInAttesa = true;
            if (!qualcuno) for (Elemento e : elementi) e.piazzato = false;
            return;
        }
        if (!qualcuno) disponiInGriglia(elementi, false);
        else piazzaNuovi();
        limitaPosizioni();
        limitaScroll();
        invalidate();
    }

    /** Posizioni attuali (in "celle", così restano giuste anche cambiando grandezza icone/testo). */
    public Map<String, float[]> posizioni() {
        Map<String, float[]> m = new HashMap<>();
        float px = cellaW + spazio, py = cellaH + spazio;
        for (Elemento e : elementi) {
            if (!e.piazzato) continue;
            boolean anima = anim != null && anim.isRunning();
            float x = anima ? e.bx : e.x, y = anima ? e.by : e.y;
            m.put(e.nome, new float[]{x / px, y / py});
        }
        return m;
    }

    // ------------------------------------------------------------ GRIGLIA

    private float larghezzaUtile() {
        return Math.max(cellaW, getWidth() - insL - insR);
    }

    private int colonne() {
        float passo = cellaW + spazio;
        return Math.max(1, (int) ((larghezzaUtile() - 8 * d + spazio) / passo));
    }

    private float xColonna(int col) {
        int cols = colonne();
        float passo = cellaW + spazio;
        float avanzo = larghezzaUtile() - (cols * passo - spazio);
        return avanzo / 2f + col * passo;
    }

    private float yRiga(int riga) {
        return 6 * d + riga * (cellaH + spazio);
    }

    /** Mette tutti in fila con gli spazi giusti (nell'ordine della lista). */
    public void disponiInGriglia(List<Elemento> ordine, boolean animato) {
        int cols = colonne();
        for (int i = 0; i < ordine.size(); i++) {
            Elemento e = ordine.get(i);
            float nx = xColonna(i % cols), ny = yRiga(i / cols);
            e.ax = e.x; e.ay = e.y; e.bx = nx; e.by = ny;
            if (!animato) { e.x = nx; e.y = ny; }
            e.piazzato = true;
        }
        if (animato) {
            if (anim != null) anim.cancel();
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(380);
            anim.setInterpolator(new DecelerateInterpolator(1.6f));
            anim.addUpdateListener(a -> {
                float f = (float) a.getAnimatedValue();
                for (Elemento e : elementi) {
                    e.x = e.ax + (e.bx - e.ax) * f;
                    e.y = e.ay + (e.by - e.ay) * f;
                }
                limitaScroll();
                invalidate();
            });
            anim.start();
            scroller.forceFinished(true);
            scrollY = 0;
        }
        invalidate();
    }

    /** Gli elementi nuovi (senza posizione salvata) vanno nel primo posto libero. */
    private void piazzaNuovi() {
        int cols = colonne();
        for (Elemento e : elementi) {
            if (e.piazzato) continue;
            for (int i = 0; i < 100000; i++) {
                float nx = xColonna(i % cols), ny = yRiga(i / cols);
                if (libero(nx, ny, e)) {
                    e.x = nx; e.y = ny; e.piazzato = true;
                    break;
                }
            }
        }
    }

    private boolean libero(float x, float y, Elemento escluso) {
        for (Elemento o : elementi) {
            if (o == escluso || !o.piazzato) continue;
            if (Math.abs(o.x - x) < cellaW * 0.8f && Math.abs(o.y - y) < cellaH * 0.8f) return false;
        }
        return true;
    }

    private void limitaPosizioni() {
        if (getWidth() == 0) return;
        float maxX = Math.max(0, larghezzaUtile() - cellaW);
        for (Elemento e : elementi) {
            if (e.x > maxX) e.x = maxX;
            if (e.x < 0) e.x = 0;
            if (e.y < 0) e.y = 0;
        }
    }

    private boolean vistaElenco() {
        return tema.vista == 1;
    }

    private float rigaH() {
        return Math.max(52 * d, tp.getTextSize() * 3.5f);
    }

    /** Ordine delle righe nella vista elenco. */
    public void setOrdineElenco(List<Elemento> l) {
        elenco.clear();
        elenco.addAll(l);
        invalidate();
    }

    private float altezzaContenuto() {
        if (vistaElenco()) return elenco.size() * rigaH() + 40 * d;
        float m = 0;
        for (Elemento e : elementi) m = Math.max(m, e.y + cellaH);
        return m + 40 * d;
    }

    private float maxScroll() {
        return Math.max(0, altezzaContenuto() - (getHeight() - insT - insB));
    }

    private void limitaScroll() {
        float m = maxScroll();
        if (scrollY > m) scrollY = m;
        if (scrollY < 0) scrollY = 0;
    }

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        if (layoutInAttesa) {
            layoutInAttesa = false;
            boolean qualcuno = false;
            for (Elemento e : elementi) if (e.piazzato) { qualcuno = true; break; }
            if (!qualcuno) disponiInGriglia(elementi, false);
            else piazzaNuovi();
        }
        limitaPosizioni();
        limitaScroll();
    }

    // ------------------------------------------------------------ DISEGNO

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(tema.sfondo);

        if (elementi.isEmpty()) {
            tp.setColor(tema.testo2);
            tp.setTextAlign(Paint.Align.CENTER);
            String m = messaggio.isEmpty() ? "Questa cartella è vuota" : messaggio;
            float cx = insL + (getWidth() - insL - insR) / 2f;
            float cy = insT + (getHeight() - insT - insB) / 2f;
            Disegni.cartella(c, cx, cy - 50 * d, 70 * d, Tema.conAlfa(tema.cartella, 90));
            c.drawText(m, cx, cy + 20 * d, tp);
            tp.setTextAlign(Paint.Align.LEFT);
            return;
        }

        c.save();
        c.clipRect(0, 0, getWidth(), getHeight());
        float ox = insL, oy = insT - scrollY;
        if (vistaElenco()) {
            for (int i = 0; i < elenco.size(); i++) disegnaRiga(c, elenco.get(i), ox, oy + i * rigaH());
            c.restore();
            return;
        }
        for (Elemento e : elementi) {
            if (trascina && trascinati.contains(e)) continue;
            disegna(c, e, ox, oy, false);
        }
        for (Elemento e : trascinati) if (trascina) disegna(c, e, ox, oy, true);
        c.restore();
    }

    private static final java.text.SimpleDateFormat DATA =
            new java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.ITALIAN);

    /** Una riga della vista elenco: icona piccola, nome e dettagli. */
    private void disegnaRiga(Canvas c, Elemento e, float l, float t) {
        float rh = rigaH();
        if (t > getHeight() || t + rh < 0) return;
        float w = getWidth() - insL - insR;
        if (e.sel) {
            rr.set(l + 2 * d, t + 2 * d, l + w - 2 * d, t + rh - 2 * d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Tema.conAlfa(tema.accento, 40));
            c.drawRoundRect(rr, 10 * d, 10 * d, p);
        } else {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Tema.conAlfa(tema.testo, 18));
            c.drawRect(l + 56 * d, t + rh - d, l + w - 8 * d, t + rh, p);
        }
        float is = Math.min(rh * 0.62f, 40 * d);
        float cx = l + 14 * d + is / 2f, cy = t + rh / 2f;
        if (e.dir) Disegni.cartella(c, cx, cy, is, tema.cartella);
        else if (OperazioniFile.immagine(e.est)) {
            Bitmap b = MINI.get(e.file.getAbsolutePath());
            if (b != null) disegnaMiniatura(c, b, cx, cy, is);
            else {
                caricaMiniatura(e.file);
                Disegni.file(c, cx, cy, is, e.est, tema.scheda, tema.testo, tema.font());
            }
        } else Disegni.file(c, cx, cy, is, e.est, tema.scheda, tema.testo, tema.font());

        float tx = l + 28 * d + is;
        float spazioTesto = w - (tx - l) - 12 * d;
        if (e.info == null) {
            String data = DATA.format(new java.util.Date(e.file.lastModified()));
            e.info = e.dir ? "Cartella · " + data : OperazioniFile.leggibile(e.file.length()) + " · " + data;
        }
        float ts = tp.getTextSize();
        tp.setColor(tema.testo);
        c.drawText(TextUtils.ellipsize(e.nome, tp, spazioTesto, TextUtils.TruncateAt.END).toString(),
                tx, cy - ts * 0.15f, tp);
        float vecchia = tp.getTextSize();
        tp.setTextSize(vecchia * 0.82f);
        tp.setColor(tema.testo2);
        c.drawText(TextUtils.ellipsize(e.info, tp, spazioTesto, TextUtils.TruncateAt.END).toString(),
                tx, cy + ts * 0.95f, tp);
        tp.setTextSize(vecchia);
    }

    private void disegna(Canvas c, Elemento e, float ox, float oy, boolean sollevato) {
        float l = ox + e.x, t = oy + e.y;
        if (t > getHeight() || t + cellaH < 0) return;

        // sfondo selezione / bersaglio
        if (e.sel || e == bersaglio || sollevato) {
            rr.set(l + 2 * d, t + 2 * d, l + cellaW - 2 * d, t + cellaH - 2 * d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Tema.conAlfa(tema.accento, e == bersaglio ? 70 : 38));
            c.drawRoundRect(rr, 14 * d, 14 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(Tema.conAlfa(tema.accento, e == bersaglio ? 200 : 120));
            c.drawRoundRect(rr, 14 * d, 14 * d, p);
            p.setStyle(Paint.Style.FILL);
        }

        float cx = l + cellaW / 2f;
        float icy = t + 8 * d + iconaPx / 2f;
        float s = sollevato ? iconaPx * 1.08f : iconaPx;

        if (e.dir) {
            Disegni.cartella(c, cx, icy, s, tema.cartella);
        } else if (OperazioniFile.immagine(e.est)) {
            Bitmap b = MINI.get(e.file.getAbsolutePath());
            if (b != null) disegnaMiniatura(c, b, cx, icy, s);
            else {
                caricaMiniatura(e.file);
                Disegni.file(c, cx, icy, s, e.est, tema.scheda, tema.testo, tema.font());
            }
        } else {
            Disegni.file(c, cx, icy, s, e.est, tema.scheda, tema.testo, tema.font());
        }

        // nome (max 2 righe)
        int lw = (int) (cellaW - 8 * d);
        if (e.lay == null || e.layLarghezza != lw) {
            tp.setColor(tema.testo);
            e.lay = StaticLayout.Builder.obtain(e.nome, 0, e.nome.length(), tp, lw)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(2)
                    .setEllipsize(TextUtils.TruncateAt.END)
                    .setIncludePad(false)
                    .build();
            e.layLarghezza = lw;
        }
        tp.setColor(tema.testo);
        c.save();
        c.translate(l + 4 * d, t + 8 * d + iconaPx + 6 * d);
        e.lay.draw(c);
        c.restore();
    }

    private void disegnaMiniatura(Canvas c, Bitmap b, float cx, float cy, float s) {
        float bw = b.getWidth(), bh = b.getHeight();
        float sc = Math.min(s / bw, s / bh);
        float w = bw * sc, hh = bh * sc;
        rr.set(cx - w / 2f, cy - hh / 2f, cx + w / 2f, cy + hh / 2f);
        c.save();
        clip.reset();
        clip.addRoundRect(rr, 8 * d, 8 * d, Path.Direction.CW);
        c.clipPath(clip);
        p.setColor(0xFFFFFFFF);
        c.drawBitmap(b, null, rr, p);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        p.setColor(Tema.conAlfa(tema.testo, 50));
        c.drawRoundRect(rr, 8 * d, 8 * d, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void caricaMiniatura(File f) {
        final String k = f.getAbsolutePath();
        if (inCarico.contains(k)) return;
        inCarico.add(k);
        final int lato = (int) (iconaPx * 1.3f);
        ES.execute(() -> {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(k, o);
                int camp = 1;
                while (o.outWidth / (camp * 2) >= lato && o.outHeight / (camp * 2) >= lato) camp *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = camp;
                Bitmap b = BitmapFactory.decodeFile(k, o2);
                if (b != null) {
                    MINI.put(k, b);
                    postInvalidate();
                }
            } catch (Throwable ignored) {
            }
        });
    }

    // ------------------------------------------------------------ TOCCO

    private Elemento elementoIn(float sx, float sy) {
        float ox = insL, oy = insT - scrollY;
        if (vistaElenco()) {
            if (sx < ox || sx > getWidth() - insR) return null;
            int i = (int) Math.floor((sy - oy) / rigaH());
            return (sy >= oy && i >= 0 && i < elenco.size()) ? elenco.get(i) : null;
        }
        for (int i = elementi.size() - 1; i >= 0; i--) {
            Elemento e = elementi.get(i);
            float l = ox + e.x, t = oy + e.y;
            if (sx >= l && sx <= l + cellaW && sy >= t && sy <= t + cellaH) return e;
        }
        return null;
    }

    private Elemento cartellaSotto(float sx, float sy) {
        float ox = insL, oy = insT - scrollY;
        for (Elemento e : elementi) {
            if (!e.dir || trascinati.contains(e)) continue;
            float l = ox + e.x, t = oy + e.y;
            if (sx >= l + cellaW * 0.12f && sx <= l + cellaW * 0.88f && sy >= t && sy <= t + 8 * d + iconaPx + 6 * d)
                return e;
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(ev);
        float x = ev.getX(), y = ev.getY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                scroller.forceFinished(true);
                if (anim != null && anim.isRunning()) anim.end();
                downX = x; downY = y; scrollAlDown = scrollY;
                mosso = false; lungoFatto = false; trascina = false;
                premuto = elementoIn(x, y);
                soloScorri = scorrimentoTrackpad(ev);
                // clic destro del mouse / trackpad: apre subito il menu
                if ((ev.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0) {
                    lungoFatto = true;
                    if (asc != null) asc.pressione(premuto);
                    return true;
                }
                h.postDelayed(lungo, ViewConfiguration.getLongPressTimeout());
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                // secondo dito sullo schermo: solo scorrimento
                if (!trascina) {
                    soloScorri = true;
                    h.removeCallbacks(lungo);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (lungoFatto) return true;
                if (!trascina && scorrimentoTrackpad(ev)) soloScorri = true;
                if (!mosso && Math.hypot(x - downX, y - downY) > slop) {
                    mosso = true;
                    h.removeCallbacks(lungo);
                    // si sposta solo una cartella già selezionata (con un tocco), e solo nella vista a icone
                    if (premuto != null && premuto.sel && !soloScorri && !vistaElenco()) iniziaTrascinamento();
                }
                if (mosso) {
                    if (trascina) {
                        // scorrimento automatico vicino ai bordi
                        if (y > getHeight() - insB - 50 * d) scrollY += 12 * d;
                        else if (y < insT + 30 * d && scrollY > 0) scrollY = Math.max(0, scrollY - 12 * d);
                        float dx = x - downX, dy = y - downY + (scrollY - scrollAlDown);
                        for (Elemento e : trascinati) {
                            float[] st = inizio.get(e);
                            e.x = st[0] + dx;
                            e.y = st[1] + dy;
                        }
                        bersaglio = cartellaSotto(x, y);
                    } else {
                        scrollY = scrollAlDown - (y - downY);
                        limitaScroll();
                    }
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(lungo);
                boolean annullato = ev.getActionMasked() == MotionEvent.ACTION_CANCEL;
                if (trascina) {
                    trascina = false;
                    Elemento b = bersaglio;
                    bersaglio = null;
                    List<Elemento> copia = new ArrayList<>(trascinati);
                    if (b != null && !annullato && asc != null) {
                        asc.rilasciaSu(copia, b);
                    } else {
                        limitaPosizioni();
                        if (asc != null) asc.posizioniCambiate();
                    }
                    trascinati.clear();
                    limitaScroll();
                    invalidate();
                } else if (mosso && !annullato) {
                    vt.computeCurrentVelocity(1000);
                    float vy = vt.getYVelocity();
                    if (Math.abs(vy) > ViewConfiguration.get(getContext()).getScaledMinimumFlingVelocity()) {
                        scroller.fling(0, (int) scrollY, 0, (int) -vy, 0, 0, 0, (int) maxScroll());
                        postInvalidateOnAnimation();
                    }
                } else if (!mosso && !lungoFatto && !annullato && asc != null) {
                    long ora = android.os.SystemClock.uptimeMillis();
                    if (premuto != null && premuto == ultimoTocco
                            && ora - tempoUltimo < ViewConfiguration.getDoubleTapTimeout() + 150) {
                        ultimoTocco = null;
                        asc.doppioTocco(premuto);       // due tocchi: apre
                    } else {
                        ultimoTocco = premuto;
                        tempoUltimo = ora;
                        asc.tocco(premuto);             // un tocco: seleziona
                    }
                }
                if (vt != null) { vt.recycle(); vt = null; }
                return true;
        }
        return true;
    }

    /** true se il movimento arriva da un trackpad con due dita (o da un puntatore senza tasto premuto). */
    private boolean scorrimentoTrackpad(MotionEvent ev) {
        if (ev.getPointerCount() > 1) return true;
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            int c = ev.getClassification();
            if (c == 3 /* TWO_FINGER_SWIPE */
                    || c == 4 /* MULTI_FINGER_SWIPE */) return true;
        }
        boolean puntatore = ev.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
                || ev.isFromSource(android.view.InputDevice.SOURCE_MOUSE)
                || ev.isFromSource(android.view.InputDevice.SOURCE_TOUCHPAD);
        // con il trackpad si sposta una cartella solo tenendo premuto il clic
        return puntatore && (ev.getButtonState() & MotionEvent.BUTTON_PRIMARY) == 0;
    }

    /** Rotellina del mouse / scorrimento a due dita inviato come "scroll". */
    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            float v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
            if (v != 0) {
                scroller.forceFinished(true);
                scrollY -= v * 64 * d;
                limitaScroll();
                invalidate();
                return true;
            }
        }
        return super.onGenericMotionEvent(ev);
    }

    private void iniziaTrascinamento() {
        trascina = true;
        trascinati.clear();
        inizio.clear();
        if (premuto.sel) {
            for (Elemento e : elementi) if (e.sel) trascinati.add(e);
        } else trascinati.add(premuto);
        for (Elemento e : trascinati) inizio.put(e, new float[]{e.x, e.y});
        // porta in primo piano
        elementi.removeAll(trascinati);
        elementi.addAll(trascinati);
    }

    /** Riporta gli elementi trascinati dove erano (se l'utente annulla lo spostamento nella cartella). */
    public void ripristina(List<Elemento> lista) {
        for (Elemento e : lista) {
            float[] st = inizio.get(e);
            if (st != null) { e.x = st[0]; e.y = st[1]; }
        }
        invalidate();
    }

    /** Rettangolo della cartella sullo schermo (per aprire il menu accanto). */
    public RectF rettangoloSchermo(Elemento e) {
        int[] l = new int[2];
        getLocationOnScreen(l);
        if (vistaElenco()) {
            int i = Math.max(0, elenco.indexOf(e));
            float y = l[1] + insT + i * rigaH() - scrollY;
            float x = l[0] + insL;
            return new RectF(x, y, x + Math.min(320 * d, getWidth() - insL - insR), y + rigaH());
        }
        float x = l[0] + insL + e.x, y = l[1] + insT + e.y - scrollY;
        return new RectF(x + 4 * d, y, x + cellaW - 4 * d, y + cellaH);
    }

    /** Punto dove l'utente ha tenuto premuto (area vuota). */
    public RectF puntoPressione() {
        int[] l = new int[2];
        getLocationOnScreen(l);
        float x = l[0] + downX, y = l[1] + downY;
        return new RectF(x, y, x, y);
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollY = scroller.getCurrY();
            limitaScroll();
            postInvalidateOnAnimation();
        }
    }

    public void tornaSu() {
        scroller.forceFinished(true);
        scrollY = 0;
        invalidate();
    }

    public float getScrollPos() {
        return scrollY;
    }

    public void setScrollPos(float s) {
        scrollY = s;
        limitaScroll();
        invalidate();
    }
}
