package gestore;

import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Gestore Files - Copyright © Ignazio Paolicelli
 * Finestra Impostazioni: stili, posizione barra, trasparenza, carattere, grandezze e colori.
 */
public class Impostazioni {

    private final MainActivity a;
    private final Tema t;
    private final Finestre f;
    private Dialog dl;
    private ScrollView sv;

    private static final int[] TAVOLOZZA = {
            0xFFFFFFFF, 0xFFF5F4EE, 0xFFF5F5F7, 0xFFE5E5EA, 0xFFAEAEB2, 0xFF6E6E73,
            0xFF3A3A3C, 0xFF262624, 0xFF1C1C1E, 0xFF000000, 0xFFFAF6EF, 0xFFEFE6D6,
            0xFFD97757, 0xFFC4633F, 0xFFFF9500, 0xFFFFC83D, 0xFFFFE08A, 0xFFB5832F,
            0xFF34C759, 0xFF2E9E6A, 0xFF5CC08E, 0xFFBDE5C8, 0xFF00A6A6, 0xFF5AC8FA,
            0xFF5EB4F3, 0xFF007AFF, 0xFF0067C0, 0xFF1D3A8A, 0xFF8AB4F8, 0xFFCFE3FF,
            0xFF7C5CD6, 0xFFA78BFA, 0xFFE6E0F5, 0xFFAF52DE, 0xFFD6547A, 0xFFF08CA8,
            0xFFFFD1DC, 0xFFFF3B30, 0xFFE5484D, 0xFF8E4EC6, 0xFF14161B, 0xFF22262E,
    };

    public Impostazioni(MainActivity a, Tema t) {
        this.a = a;
        this.t = t;
        this.f = new Finestre(a, t);
    }

    private int dp(float v) {
        return f.dp(v);
    }

    public void mostra() {
        mostra(0);
    }

    private void ricostruisci() {
        int y = sv != null ? sv.getScrollY() : 0;
        if (dl != null) dl.dismiss();
        mostra(y);
    }

    private void cambiato(boolean ridisegnaFinestra) {
        t.salva();
        a.applicaTema();
        if (ridisegnaFinestra) ricostruisci();
    }

    private TextView sezione(LinearLayout c, String s) {
        TextView tv = f.testo(s.toUpperCase(), t.grandezzaTesto - 2, t.testo2, true);
        tv.setLetterSpacing(0.08f);
        tv.setPadding(dp(2), dp(18), 0, dp(8));
        c.addView(tv);
        return tv;
    }

    private void mostra(final int scroll) {
        LinearLayout esterno = f.colonna();
        LinearLayout testa = new LinearLayout(a);
        testa.setGravity(Gravity.CENTER_VERTICAL);
        Disegni.LogoView logo = new Disegni.LogoView(a, t.cartella);
        testa.addView(logo, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView ti = f.testo("  Impostazioni", t.grandezzaTesto + 6, t.testo, true);
        testa.addView(ti, new LinearLayout.LayoutParams(0, -2, 1));
        FrameLayout chiudi = new FrameLayout(a);
        chiudi.addView(new Disegni.IconaView(a, "chiudi", t.testo2), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        chiudi.setBackground(f.tocco(0, 20));
        chiudi.setOnClickListener(v -> dl.dismiss());
        testa.addView(chiudi, new LinearLayout.LayoutParams(dp(40), dp(40)));
        esterno.addView(testa);

        sv = new ScrollView(a);
        LinearLayout c = f.colonna();
        sv.addView(c);
        esterno.addView(sv, new LinearLayout.LayoutParams(-1, -2));

        // ---------------- STILI
        sezione(c, "Stile");
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout stili = new LinearLayout(a);
        hs.addView(stili);
        for (int i = 0; i < Tema.STILI.length; i++) {
            final int k = i;
            stili.addView(schedaStile(i, v -> {
                t.applicaStile(k);
                cambiato(true);
            }));
        }
        c.addView(hs);

        // ---------------- POSIZIONE BARRA
        sezione(c, "Posizione della barra");
        LinearLayout pos = new LinearLayout(a);
        pos.setBackground(f.fondo(Tema.conAlfa(t.testo, 14), 14));
        pos.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < 4; i++) {
            final int k = i;
            boolean on = t.posizioneBarra == i;
            TextView b = f.testo(Tema.NOMI_POSIZIONE[i], t.grandezzaTesto, on ? Color.WHITE : t.testo, on);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(10), 0, dp(10));
            b.setBackground(f.tocco(on ? t.accento : 0, 11));
            b.setOnClickListener(v -> {
                t.posizioneBarra = k;
                cambiato(true);
            });
            pos.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        c.addView(pos);

        // ---------------- TRASPARENZA
        cursore(c, "Opacità della barra", 30, 100, t.opacitaBarra, "%", v -> {
            t.opacitaBarra = v;
            cambiato(false);
        });

        // ---------------- CARATTERE
        sezione(c, "Carattere");
        HorizontalScrollView hf = new HorizontalScrollView(a);
        hf.setHorizontalScrollBarEnabled(false);
        LinearLayout car = new LinearLayout(a);
        hf.addView(car);
        for (int i = 0; i < Tema.NOMI_CARATTERI.length; i++) {
            final int k = i;
            boolean on = t.carattere == i;
            TextView b = new TextView(a);
            b.setText(Tema.NOMI_CARATTERI[i]);
            b.setTypeface(Tema.fontDi(i));
            b.setTextSize(t.grandezzaTesto + 1);
            b.setTextColor(on ? Color.WHITE : t.testo);
            b.setPadding(dp(16), dp(10), dp(16), dp(10));
            b.setBackground(f.tocco(on ? t.accento : Tema.conAlfa(t.testo, 14), 20));
            b.setOnClickListener(v -> {
                t.carattere = k;
                cambiato(true);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8);
            car.addView(b, lp);
        }
        c.addView(hf);

        // ---------------- GRANDEZZE
        cursore(c, "Grandezza del testo", 11, 24, t.grandezzaTesto, " pt", v -> {
            t.grandezzaTesto = v;
            cambiato(true);
        });
        cursore(c, "Grandezza delle cartelle", 40, 120, t.grandezzaIcone, "", v -> {
            t.grandezzaIcone = v;
            cambiato(false);
        });

        // ---------------- COLORI
        sezione(c, "Colori personalizzati");
        String[] nomi = {"Sfondo", "Barra", "Testo", "Testo secondario", "Colore principale", "Cartelle", "Fogli dei file"};
        int[] valori = {t.sfondo, t.barra, t.testo, t.testo2, t.accento, t.cartella, t.scheda};
        LinearLayout colori = f.colonna();
        colori.setBackground(f.fondo(Tema.conAlfa(t.testo, 10), 14));
        for (int i = 0; i < nomi.length; i++) {
            final int k = i;
            LinearLayout r = new LinearLayout(a);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(14), dp(10), dp(14), dp(10));
            r.setBackground(f.tocco(0, 14));
            r.addView(f.testo(nomi[i], t.grandezzaTesto + 1, t.testo, false), new LinearLayout.LayoutParams(0, -2, 1));
            View pal = new View(a);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(valori[i]);
            g.setStroke(dp(1), Tema.conAlfa(t.testo, 60));
            pal.setBackground(g);
            r.addView(pal, new LinearLayout.LayoutParams(dp(28), dp(28)));
            r.setOnClickListener(v -> tavolozza(nomi[k], valori[k], col -> {
                switch (k) {
                    case 0: t.sfondo = col; break;
                    case 1: t.barra = col; break;
                    case 2: t.testo = col; break;
                    case 3: t.testo2 = col; break;
                    case 4: t.accento = col; break;
                    case 5: t.cartella = col; break;
                    case 6: t.scheda = col; break;
                }
                t.stile = -1;
                cambiato(true);
            }));
            colori.addView(r);
        }
        c.addView(colori);

        // ---------------- ALTRO
        sezione(c, "Altro");
        LinearLayout rn = new LinearLayout(a);
        rn.setGravity(Gravity.CENTER_VERTICAL);
        rn.setPadding(dp(14), dp(6), dp(8), dp(6));
        rn.setBackground(f.fondo(Tema.conAlfa(t.testo, 10), 14));
        rn.addView(f.testo("Mostra file nascosti", t.grandezzaTesto + 1, t.testo, false), new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(a);
        sw.setChecked(t.nascosti);
        sw.setThumbTintList(ColorStateList.valueOf(t.accento));
        sw.setTrackTintList(ColorStateList.valueOf(Tema.conAlfa(t.accento, 110)));
        sw.setOnCheckedChangeListener((b, on) -> {
            t.nascosti = on;
            t.salva();
            a.ricarica();
        });
        rn.addView(sw);
        c.addView(rn);

        TextView cp = f.testo("Gestore Files 1.0\nCopyright © Ignazio Paolicelli", t.grandezzaTesto - 2, t.testo2, false);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, dp(22), 0, dp(6));
        c.addView(cp);

        dl = f.nuova(esterno, 560);
        android.view.Window w = dl.getWindow();
        if (w != null) {
            int hh = a.getResources().getDisplayMetrics().heightPixels;
            w.setLayout(Math.min((int) (a.getResources().getDisplayMetrics().widthPixels * 0.94f), dp(560)),
                    (int) (hh * 0.86f));
            sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1));
        }
        dl.show();
        sv.post(() -> sv.scrollTo(0, scroll));
    }

    private View schedaStile(int i, View.OnClickListener cl) {
        int[] s = Tema.STILI[i];
        LinearLayout card = f.colonna();
        GradientDrawable g = f.fondo(s[0], 16);
        boolean on = t.stile == i;
        g.setStroke(dp(on ? 3 : 1), on ? t.accento : Tema.conAlfa(t.testo, 40));
        card.setBackground(g);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout dentro = new LinearLayout(a);
        View barra = new View(a);
        barra.setBackground(f.fondo(s[1], 6));
        dentro.addView(barra, new LinearLayout.LayoutParams(dp(22), dp(50)));
        LinearLayout cart = new LinearLayout(a);
        cart.setGravity(Gravity.CENTER);
        cart.addView(new Disegni.LogoView(a, s[5]), new LinearLayout.LayoutParams(dp(30), dp(30)));
        cart.addView(new Disegni.LogoView(a, s[5]), new LinearLayout.LayoutParams(dp(30), dp(30)));
        dentro.addView(cart, new LinearLayout.LayoutParams(dp(78), dp(50)));
        card.addView(dentro);
        TextView n = new TextView(a);
        n.setText(Tema.NOMI_STILI[i]);
        n.setTextColor(s[2]);
        n.setTextSize(12);
        n.setTypeface(t.fontGrassetto());
        n.setPadding(dp(2), dp(6), 0, 0);
        LinearLayout.LayoutParams lpN = new LinearLayout.LayoutParams(-2, -2);
        card.addView(n, lpN);
        View acc = new View(a);
        acc.setBackground(f.fondo(s[4], 3));
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(dp(26), dp(5));
        lpA.topMargin = dp(4);
        card.addView(acc, lpA);
        card.setOnClickListener(cl);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(118), -2);
        lp.rightMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    interface Valore { void v(int x); }

    private void cursore(LinearLayout c, String nome, int min, int max, int val, String unita, Valore cb) {
        LinearLayout r = new LinearLayout(a);
        r.setPadding(dp(2), dp(18), 0, dp(4));
        TextView tv = f.testo(nome.toUpperCase(), t.grandezzaTesto - 2, t.testo2, true);
        tv.setLetterSpacing(0.08f);
        r.addView(tv, new LinearLayout.LayoutParams(0, -2, 1));
        TextView vv = f.testo(val + unita, t.grandezzaTesto, t.testo, true);
        r.addView(vv);
        c.addView(r);
        SeekBar sb = new SeekBar(a);
        sb.setMax(max - min);
        sb.setProgress(val - min);
        sb.setProgressTintList(ColorStateList.valueOf(t.accento));
        sb.setThumbTintList(ColorStateList.valueOf(t.accento));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(Tema.conAlfa(t.testo, 60)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                vv.setText((p + min) + unita);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                cb.v(s.getProgress() + min);
            }
        });
        c.addView(sb, new LinearLayout.LayoutParams(-1, dp(36)));
    }

    private void tavolozza(String nome, int attuale, Valore cb) {
        LinearLayout c = f.colonna();
        c.addView(f.testo(nome, t.grandezzaTesto + 4, t.testo, true));
        final Dialog[] d = new Dialog[1];
        int col = 6;
        LinearLayout riga = null;
        for (int i = 0; i < TAVOLOZZA.length; i++) {
            if (i % col == 0) {
                riga = new LinearLayout(a);
                riga.setGravity(Gravity.CENTER);
                riga.setPadding(0, dp(i == 0 ? 14 : 4), 0, dp(4));
                c.addView(riga, new LinearLayout.LayoutParams(-1, -2));
            }
            final int k = TAVOLOZZA[i];
            View v = new View(a);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(k);
            boolean on = (k | 0xFF000000) == (attuale | 0xFF000000);
            g.setStroke(dp(on ? 3 : 1), on ? t.accento : Tema.conAlfa(t.testo, 60));
            v.setBackground(g);
            v.setOnClickListener(x -> {
                d[0].dismiss();
                cb.v(k);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
            lp.leftMargin = dp(5);
            lp.rightMargin = dp(5);
            riga.addView(v, lp);
        }
        d[0] = f.nuova(c, 420);
        d[0].show();
    }
}
